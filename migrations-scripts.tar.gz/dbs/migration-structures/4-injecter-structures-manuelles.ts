#!/usr/bin/env tsx

import fs from 'node:fs'
import { parse } from 'csv-parse/sync'
import prisma from '../../prisma/prismaClient'
import { PrismaStructureRepository } from '@/gateways/PrismaStructureRepository'

// Types
type StructureACompleter = {
  siret: string
  membre_nom_origine: string
  departement_code: string
  nb_membres: string
  nom: string
  categorie_juridique: string
  categorie_juridique_libelle: string
  activite_principale: string
  numero_voie: string
  nom_voie: string
  code_postal: string
  nom_commune: string
  code_insee: string
  raison_non_trouve: string
}

// Configuration
const CSV_INPUT = 'dbs/migration-structures/structures-non-trouvees-a-completer.csv'
const DRY_RUN = process.argv.includes('--dry-run')
const MAX_STRUCTURES = process.argv.includes('--limit')
  ? Number.parseInt(process.argv[process.argv.indexOf('--limit') + 1] || '10', 10)
  : undefined

// Fonction de validation
function validerStructure(structure: StructureACompleter): { valide: boolean, erreurs: string[] } {
  const erreurs: string[] = []

  // Vérifications obligatoires
  if (!structure.nom || structure.nom.trim() === '') {
    erreurs.push('Le nom est obligatoire')
  }
  if (!structure.siret || structure.siret.trim() === '' || structure.siret.length !== 14) {
    erreurs.push('Le SIRET est obligatoire et doit faire 14 caractères')
  }

  // Vérifications adresse (au moins le code postal et la commune)
  if (!structure.code_postal || structure.code_postal.trim() === '') {
    erreurs.push('Le code postal est obligatoire')
  }
  if (!structure.nom_commune || structure.nom_commune.trim() === '') {
    erreurs.push('Le nom de la commune est obligatoire')
  }

  return {
    valide: erreurs.length === 0,
    erreurs,
  }
}

// Fonction principale
async function main() {
  console.log('🚀 Démarrage du script d\'injection des structures complétées manuellement\n')

  if (DRY_RUN) {
    console.log('🔍 MODE DRY-RUN : Aucune modification ne sera effectuée\n')
  }

  // Vérifier la présence du CSV d'entrée
  if (!fs.existsSync(CSV_INPUT)) {
    console.error(`❌ Fichier CSV non trouvé : ${CSV_INPUT}`)
    console.log('💡 Ce fichier doit être créé par le script 2-recuperer-donnees-sirene.ts')
    console.log('   et complété manuellement avec les données manquantes.')
    process.exit(1)
  }

  // Lire le CSV d'entrée
  console.log(`📖 Lecture du fichier : ${CSV_INPUT}`)
  const csvContent = fs.readFileSync(CSV_INPUT, 'utf-8')
  const structures: StructureACompleter[] = parse(csvContent, {
    columns: true,
    skip_empty_lines: true,
  })

  console.log(`📊 ${structures.length} structures à traiter\n`)

  if (structures.length === 0) {
    console.log('⚠️  Aucune structure à injecter')
    process.exit(0)
  }

  // Valider les structures
  console.log('🔍 Validation des données...')
  const structuresValides: StructureACompleter[] = []
  const structuresInvalides: Array<{ structure: StructureACompleter, erreurs: string[] }> = []

  for (const structure of structures) {
    const validation = validerStructure(structure)
    if (validation.valide) {
      structuresValides.push(structure)
    } else {
      structuresInvalides.push({
        structure,
        erreurs: validation.erreurs,
      })
    }
  }

  console.log(`   ✅ ${structuresValides.length} structures valides`)
  console.log(`   ❌ ${structuresInvalides.length} structures invalides\n`)

  if (structuresInvalides.length > 0) {
    console.log('❌ STRUCTURES INVALIDES :')
    for (const { structure, erreurs } of structuresInvalides) {
      console.log(`   ${structure.siret} - ${structure.membre_nom_origine}`)
      for (const erreur of erreurs) {
        console.log(`      - ${erreur}`)
      }
    }
    console.log('\n⚠️  Veuillez corriger ces erreurs avant de continuer')

    if (structuresValides.length === 0) {
      process.exit(1)
    }

    console.log('\n💡 Continuer avec les structures valides ? (Ctrl+C pour annuler)\n')
  }

  const total = MAX_STRUCTURES
    ? Math.min(structuresValides.length, MAX_STRUCTURES)
    : structuresValides.length

  console.log(`📌 ${total} structures à injecter\n`)

  // Créer le repository
  const structureRepository = new PrismaStructureRepository()

  // Statistiques
  let compteur = 0
  let crees = 0
  let existants = 0
  let erreurs = 0
  const erreursDetails: Array<{ siret: string, erreur: string }> = []

  // Traiter chaque structure
  for (const structure of structuresValides.slice(0, MAX_STRUCTURES)) {
    compteur += 1
    const progression = `[${compteur}/${total}]`

    try {
      console.log(`${progression} Traitement du SIRET ${structure.siret} - ${structure.nom}`)

      // Vérifier si la structure existe déjà
      const existante = await structureRepository.getBySiret(structure.siret)

      if (existante) {
        console.log(`  ℹ️  Structure déjà existante (ID: ${existante.state.uid.value})`)
        existants += 1
        continue
      }

      if (DRY_RUN) {
        console.log('  🔍 [DRY-RUN] Structure serait créée')
        crees += 1
        continue
      }

      // Créer la structure
      const nouvelleStructure = await structureRepository.create({
        adresse: [
          structure.numero_voie,
          structure.nom_voie,
          structure.code_postal,
          structure.nom_commune,
        ].filter(Boolean).join(', '),
        categorieJuridique: structure.categorie_juridique,
        categorieJuridiqueLibelle: structure.categorie_juridique_libelle || 'Non renseigné',
        codeInsee: structure.code_insee,
        codePostal: structure.code_postal,
        commune: structure.nom_commune,
        departementCode: structure.departement_code,
        identifiantEtablissement: structure.siret,
        nom: structure.nom,
        nomVoie: structure.nom_voie,
        numeroVoie: structure.numero_voie,
      })

      console.log(`  ✅ Structure créée (ID: ${nouvelleStructure.state.uid.value})`)
      crees += 1
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Erreur inconnue'
      console.log(`  ❌ Erreur : ${message}`)
      erreurs += 1
      erreursDetails.push({
        siret: structure.siret,
        erreur: message,
      })
    }
  }

  // Résumé
  console.log('\n📈 RÉSUMÉ')
  console.log(`   Total validé        : ${structuresValides.length}`)
  console.log(`   Total invalide      : ${structuresInvalides.length}`)
  console.log(`   Total traité        : ${compteur}`)
  console.log(`   ✅ Structures créées : ${crees}`)
  console.log(`   ℹ️  Déjà existantes   : ${existants}`)
  console.log(`   ❌ Erreurs           : ${erreurs}`)

  if (erreursDetails.length > 0) {
    console.log('\n❌ DÉTAIL DES ERREURS :')
    for (const { siret, erreur } of erreursDetails) {
      console.log(`   ${siret} : ${erreur}`)
    }
  }

  if (DRY_RUN) {
    console.log('\n🔍 MODE DRY-RUN : Aucune modification n\'a été effectuée')
    console.log('💡 Pour effectuer l\'injection réelle, relancez sans --dry-run')
  } else {
    console.log('\n✨ Injection terminée avec succès !')
    console.log('\n💡 Prochaine étape :')
    console.log('   Appliquez le script de migration pour lier les membres :')
    console.log('   docker compose exec postgres-dev psql -U min -f "Nettoyage de la donnée.sql"')
  }
}

main()
  .catch((error) => {
    console.error('❌ Erreur fatale :', error)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
