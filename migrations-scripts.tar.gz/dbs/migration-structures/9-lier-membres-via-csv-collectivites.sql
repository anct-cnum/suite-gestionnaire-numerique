-- Script pour lier les membres (préfectures, départements, SGAR) via le CSV collectivites-sirene.csv
-- Ce CSV contient le mapping membre_id → siret_siege

-- ============================================================================
-- IMPORT DU CSV DANS UNE TABLE TEMPORAIRE
-- ============================================================================

CREATE TEMP TABLE temp_collectivites_mapping (
  type TEXT,
  code TEXT,
  nom_membre TEXT,
  membre_id TEXT,
  siret_siege TEXT,
  denomination_sirene TEXT,
  adresse TEXT,
  code_postal TEXT,
  commune TEXT,
  code_commune TEXT,
  categorie_juridique TEXT,
  etat TEXT,
  erreur TEXT
);

-- Importer le CSV
\copy temp_collectivites_mapping FROM '/tmp/collectivites-sirene.csv' WITH (FORMAT CSV, HEADER, DELIMITER ',', ENCODING 'UTF8');

-- ============================================================================
-- STATISTIQUES AVANT
-- ============================================================================

SELECT '======================================' as separateur;
SELECT 'AVANT LIAISON (via CSV collectivités)' as etape;
SELECT '======================================' as separateur;

SELECT
  'Membres prefecture-XX / departement-XX / sgar-XX' as type,
  COUNT(*) as total_membres,
  COUNT(structure_id) as membres_deja_lies,
  COUNT(*) - COUNT(structure_id) as membres_non_lies
FROM min.membre m
WHERE m.statut IN ('confirme', 'supprimer')
  AND (
    m.id LIKE 'prefecture-%'
    OR m.id LIKE 'departement-%'
    OR m.id LIKE 'sgar-%'
  );

-- ============================================================================
-- LIAISON : Membres via le mapping CSV
-- ============================================================================

UPDATE min.membre m
SET structure_id = s.id
FROM temp_collectivites_mapping tcm
INNER JOIN main.structure s ON s.siret = tcm.siret_siege
WHERE m.statut IN ('confirme', 'supprimer')
  AND m.structure_id IS NULL
  AND m.id = tcm.membre_id
  AND tcm.etat = 'ACTIF';

SELECT '✓ Liaison membres via CSV collectivités terminée' as message;

-- ============================================================================
-- STATISTIQUES APRÈS
-- ============================================================================

SELECT '======================================' as separateur;
SELECT 'APRÈS LIAISON (via CSV collectivités)' as etape;
SELECT '======================================' as separateur;

SELECT
  'Membres prefecture-XX / departement-XX / sgar-XX' as type,
  COUNT(*) as total_membres,
  COUNT(structure_id) as membres_lies,
  COUNT(*) - COUNT(structure_id) as membres_non_lies
FROM min.membre m
WHERE m.statut IN ('confirme', 'supprimer')
  AND (
    m.id LIKE 'prefecture-%'
    OR m.id LIKE 'departement-%'
    OR m.id LIKE 'sgar-%'
  );

-- ============================================================================
-- RÉSUMÉ GLOBAL FINAL
-- ============================================================================

SELECT '======================================' as separateur;
SELECT 'RÉSUMÉ GLOBAL FINAL' as etape;
SELECT '======================================' as separateur;

WITH tous_membres AS (
  SELECT
    COUNT(*) as total,
    COUNT(structure_id) as lies
  FROM min.membre m
  WHERE m.statut IN ('confirme', 'supprimer')
)
SELECT
  total as total_membres,
  lies as membres_lies,
  total - lies as membres_non_lies,
  ROUND(100.0 * lies / total, 2) as pourcentage_lies
FROM tous_membres;

-- Nettoyer
DROP TABLE temp_collectivites_mapping;
