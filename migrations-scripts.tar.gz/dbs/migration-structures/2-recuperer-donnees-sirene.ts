#!/usr/bin/env tsx

import fs from 'node:fs'
import path from 'node:path'
import { config } from 'dotenv'
import { parse } from 'csv-parse/sync'
import { stringify } from 'csv-stringify/sync'
import { ApiSireneLoader } from '@/gateways/apiEntreprise/ApiSireneLoader'

// Charger les variables d'environnement depuis .env.local
config({ path: '.env.local' })

// Types
type StructureManquante = {
  identifiant: string
  type_identifiant: 'SIRET' | 'SIREN' | 'CODE_INSEE'
  membre_nom: string
  departement_code: string
  nb_membres_avec_cet_identifiant: string
}

type StructureEnrichie = {
  siret: string
  membre_nom_origine: string
  departement_code: string
  nb_membres: string
  // Données API SIRENE
  nom: string
  adresse_complete: string
  numero_voie: string
  nom_voie: string
  code_postal: string
  commune: string
  code_insee: string
  categorie_juridique: string
  activite_principale: string
  statut: 'OK' | 'NON_TROUVE' | 'ERREUR'
  erreur?: string
}

type StructureACompleter = {
  // Identification
  siret: string
  membre_nom_origine: string
  departement_code: string
  nb_membres: string
  // Données structure à compléter
  nom: string
  categorie_juridique: string
  categorie_juridique_libelle: string
  activite_principale: string
  // Données adresse à compléter
  numero_voie: string
  nom_voie: string
  code_postal: string
  nom_commune: string
  code_insee: string
  // Commentaire
  raison_non_trouve: string
}

// Configuration
const CSV_INPUT = 'dbs/migration-structures/structures-manquantes.csv'
const CSV_OUTPUT = 'dbs/migration-structures/structures-enrichies.csv'
const CSV_NON_TROUVEES = 'dbs/migration-structures/structures-non-trouvees-a-completer.csv'
const MAX_RETRIES = 3 // Nombre de tentatives en cas d'erreur de rate limit
const MAX_STRUCTURES = process.argv.includes('--limit')
  ? Number.parseInt(process.argv[process.argv.indexOf('--limit') + 1] || '10', 10)
  : undefined

// Gestion du rate limit API SIRENE : 30 requêtes, puis attendre 65 secondes
let requestCount = 0
let batchStartTime = Date.now()

async function attendreRateLimit(): Promise<void> {
  requestCount++

  if (requestCount % 30 === 0) {
    const elapsed = Date.now() - batchStartTime
    const waitTime = 65000 - elapsed

    if (waitTime > 0) {
      console.log(`\n⏳ Rate limit API SIRENE : attente de ${Math.ceil(waitTime / 1000)}s avant le prochain batch (30 requêtes effectuées)...\n`)
      await new Promise(resolve => { setTimeout(resolve, waitTime) })
    }

    batchStartTime = Date.now()
  }
}

// Fonction pour attendre (utilisée pour les retries)
const wait = (ms: number) => new Promise(resolve => { setTimeout(resolve, ms) })

// Types pour recherche multicritère API SIRENE
type SireneRecherche = {
  header: {
    statut: number
    message: string
    total: number
  }
  etablissements: Array<{
    siret: string
    etablissementSiege: boolean
    uniteLegale: {
      denominationUniteLegale: string | null
      nomUniteLegale: string | null
      categorieJuridiqueUniteLegale: string
      activitePrincipaleUniteLegale: string
      etatAdministratifUniteLegale: string
    }
    adresseEtablissement: {
      numeroVoieEtablissement: string | null
      typeVoieEtablissement: string | null
      libelleVoieEtablissement: string | null
      codePostalEtablissement: string | null
      libelleCommuneEtablissement: string | null
      codeCommuneEtablissement: string | null
    }
    periodesEtablissement: Array<{
      etatAdministratifEtablissement: string
      enseigne1Etablissement: string | null
    }>
  }>
}

// Rechercher un EPCI par SIREN via API SIRENE multicritère
async function rechercherEPCIParSiren(siren: string, nomEPCI: string): Promise<{
  siret: string
  denomination: string
  adresse: string
  numeroVoie: string
  nomVoie: string
  codePostal: string
  commune: string
  codeInsee: string
  categorieJuridiqueCode: string
  activitePrincipale: string
} | null> {
  try {
    if (!process.env.INSEE_API_KEY) {
      throw new Error('Variable d\'environnement INSEE_API_KEY non définie')
    }

    // Recherche par SIREN (les 9 premiers chiffres du SIRET)
    // On cherche sans filtre de catégorie juridique car les EPCI peuvent avoir différentes catégories
    let query = `siren:${siren}`

    const url = `https://api.insee.fr/api-sirene/3.11/siret?q=${encodeURIComponent(query)}&nombre=100`

    const response = await fetch(url, {
      headers: {
        'Accept': 'application/json',
        'X-INSEE-Api-Key-Integration': process.env.INSEE_API_KEY,
      },
      signal: AbortSignal.timeout(10000),
    })

    if (!response.ok) {
      return null
    }

    const data: SireneRecherche = await response.json()

    // Filtrer pour ne garder que les sièges sociaux actifs
    const siegesActifs = data.etablissements.filter(etab =>
      etab.etablissementSiege &&
      etab.periodesEtablissement[0]?.etatAdministratifEtablissement === 'A' &&
      etab.uniteLegale.etatAdministratifUniteLegale === 'A'
    )

    if (siegesActifs.length > 0) {
      const etab = siegesActifs[0]

      const adresseComplete = [
        etab.adresseEtablissement.numeroVoieEtablissement,
        etab.adresseEtablissement.typeVoieEtablissement,
        etab.adresseEtablissement.libelleVoieEtablissement,
      ].filter(Boolean).join(' ')

      return {
        siret: etab.siret,
        denomination: etab.uniteLegale.denominationUniteLegale || etab.uniteLegale.nomUniteLegale || nomEPCI,
        adresse: adresseComplete,
        numeroVoie: etab.adresseEtablissement.numeroVoieEtablissement || '',
        nomVoie: etab.adresseEtablissement.libelleVoieEtablissement || '',
        codePostal: etab.adresseEtablissement.codePostalEtablissement || '',
        commune: etab.adresseEtablissement.libelleCommuneEtablissement || '',
        codeInsee: etab.adresseEtablissement.codeCommuneEtablissement || '',
        categorieJuridiqueCode: etab.uniteLegale.categorieJuridiqueUniteLegale,
        activitePrincipale: etab.uniteLegale.activitePrincipaleUniteLegale,
      }
    }

    // Si pas de siège actif, prendre juste un siège
    const sieges = data.etablissements.filter(etab => etab.etablissementSiege)
    if (sieges.length > 0) {
      const etab = sieges[0]

      const adresseComplete = [
        etab.adresseEtablissement.numeroVoieEtablissement,
        etab.adresseEtablissement.typeVoieEtablissement,
        etab.adresseEtablissement.libelleVoieEtablissement,
      ].filter(Boolean).join(' ')

      return {
        siret: etab.siret,
        denomination: etab.uniteLegale.denominationUniteLegale || etab.uniteLegale.nomUniteLegale || nomEPCI,
        adresse: adresseComplete,
        numeroVoie: etab.adresseEtablissement.numeroVoieEtablissement || '',
        nomVoie: etab.adresseEtablissement.libelleVoieEtablissement || '',
        codePostal: etab.adresseEtablissement.codePostalEtablissement || '',
        commune: etab.adresseEtablissement.libelleCommuneEtablissement || '',
        codeInsee: etab.adresseEtablissement.codeCommuneEtablissement || '',
        categorieJuridiqueCode: etab.uniteLegale.categorieJuridiqueUniteLegale,
        activitePrincipale: etab.uniteLegale.activitePrincipaleUniteLegale,
      }
    }

    return null
  } catch (error) {
    console.error(`  ❌ Erreur recherche SIREN ${siren}:`, error instanceof Error ? error.message : error)
    return null
  }
}

// Rechercher une commune par CODE_INSEE via API SIRENE multicritère
async function rechercherCommuneParCodeInsee(codeInsee: string, nomCommune: string): Promise<{
  siret: string
  denomination: string
  adresse: string
  numeroVoie: string
  nomVoie: string
  codePostal: string
  commune: string
  codeInsee: string
  categorieJuridiqueCode: string
  activitePrincipale: string
} | null> {
  try {
    if (!process.env.INSEE_API_KEY) {
      throw new Error('Variable d\'environnement INSEE_API_KEY non définie')
    }

    // Recherche multicritère : code INSEE + catégorie juridique 7xxx (collectivités territoriales)
    let query = `codeCommuneEtablissement:${codeInsee} AND categorieJuridiqueUniteLegale:7*`

    const url = `https://api.insee.fr/api-sirene/3.11/siret?q=${encodeURIComponent(query)}&nombre=100`

    const response = await fetch(url, {
      headers: {
        'Accept': 'application/json',
        'X-INSEE-Api-Key-Integration': process.env.INSEE_API_KEY,
      },
      signal: AbortSignal.timeout(10000),
    })

    if (!response.ok) {
      return null
    }

    const data: SireneRecherche = await response.json()

    // Filtrer pour ne garder que les sièges sociaux actifs
    const siegesActifs = data.etablissements.filter(etab =>
      etab.etablissementSiege &&
      etab.periodesEtablissement[0]?.etatAdministratifEtablissement === 'A' &&
      etab.uniteLegale.etatAdministratifUniteLegale === 'A'
    )

    if (siegesActifs.length > 0) {
      const etab = siegesActifs[0]

      const adresseComplete = [
        etab.adresseEtablissement.numeroVoieEtablissement,
        etab.adresseEtablissement.typeVoieEtablissement,
        etab.adresseEtablissement.libelleVoieEtablissement,
      ].filter(Boolean).join(' ')

      return {
        siret: etab.siret,
        denomination: etab.uniteLegale.denominationUniteLegale || etab.uniteLegale.nomUniteLegale || nomCommune,
        adresse: adresseComplete,
        numeroVoie: etab.adresseEtablissement.numeroVoieEtablissement || '',
        nomVoie: etab.adresseEtablissement.libelleVoieEtablissement || '',
        codePostal: etab.adresseEtablissement.codePostalEtablissement || '',
        commune: etab.adresseEtablissement.libelleCommuneEtablissement || '',
        codeInsee: etab.adresseEtablissement.codeCommuneEtablissement || codeInsee,
        categorieJuridiqueCode: etab.uniteLegale.categorieJuridiqueUniteLegale,
        activitePrincipale: etab.uniteLegale.activitePrincipaleUniteLegale,
      }
    }

    // Si pas de siège actif, prendre juste un siège
    const sieges = data.etablissements.filter(etab => etab.etablissementSiege)
    if (sieges.length > 0) {
      const etab = sieges[0]

      const adresseComplete = [
        etab.adresseEtablissement.numeroVoieEtablissement,
        etab.adresseEtablissement.typeVoieEtablissement,
        etab.adresseEtablissement.libelleVoieEtablissement,
      ].filter(Boolean).join(' ')

      return {
        siret: etab.siret,
        denomination: etab.uniteLegale.denominationUniteLegale || etab.uniteLegale.nomUniteLegale || nomCommune,
        adresse: adresseComplete,
        numeroVoie: etab.adresseEtablissement.numeroVoieEtablissement || '',
        nomVoie: etab.adresseEtablissement.libelleVoieEtablissement || '',
        codePostal: etab.adresseEtablissement.codePostalEtablissement || '',
        commune: etab.adresseEtablissement.libelleCommuneEtablissement || '',
        codeInsee: etab.adresseEtablissement.codeCommuneEtablissement || codeInsee,
        categorieJuridiqueCode: etab.uniteLegale.categorieJuridiqueUniteLegale,
        activitePrincipale: etab.uniteLegale.activitePrincipaleUniteLegale,
      }
    }

    return null
  } catch (error) {
    console.error(`  ❌ Erreur recherche CODE_INSEE ${codeInsee}:`, error instanceof Error ? error.message : error)
    return null
  }
}

// Fonction principale
async function main() {
  console.log('🚀 Démarrage du script de récupération des données SIRENE\n')

  // Vérifier la présence du CSV d'entrée
  if (!fs.existsSync(CSV_INPUT)) {
    console.error(`❌ Fichier CSV non trouvé : ${CSV_INPUT}`)
    console.log('💡 Lancez d\'abord le script SQL pour extraire les structures manquantes :')
    console.log('   docker compose exec postgres-dev psql -U min -f dbs/migration-structures/1-extraire-structures-manquantes.sql')
    process.exit(1)
  }

  // Vérifier la clé API INSEE
  if (!process.env.INSEE_API_KEY) {
    console.error('❌ Variable d\'environnement INSEE_API_KEY non définie')
    process.exit(1)
  }

  // Lire le CSV d'entrée
  console.log(`📖 Lecture du fichier : ${CSV_INPUT}`)
  const csvContent = fs.readFileSync(CSV_INPUT, 'utf-8')
  const structures: StructureManquante[] = parse(csvContent, {
    columns: true,
    skip_empty_lines: true,
  })

  // Toutes les structures doivent être traitées
  const structuresAPIable = structures

  console.log(`📊 ${structures.length} structures au total`)
  console.log(`   - ${structuresAPIable.filter(s => s.type_identifiant === 'SIRET').length} SIRET (14 chiffres)`)
  console.log(`   - ${structuresAPIable.filter(s => s.type_identifiant === 'SIREN').length} SIREN/EPCI (9 chiffres)`)
  console.log(`   - ${structuresAPIable.filter(s => s.type_identifiant === 'CODE_INSEE').length} CODE_INSEE/Communes (5 chiffres) → recherche multicritère\n`)

  const total = MAX_STRUCTURES ? Math.min(structuresAPIable.length, MAX_STRUCTURES) : structuresAPIable.length
  console.log(`🔄 ${total} structures à traiter via API SIRENE`)

  // Estimation du temps
  const batches = Math.ceil(total / 30)
  const estimatedMinutes = Math.ceil(batches * 65 / 60)
  console.log(`⏱️  Temps estimé : ~${estimatedMinutes} minutes (rate limit API SIRENE : 30 req / 65s)\n`)

  // Créer le loader API SIRENE
  const sireneLoader = new ApiSireneLoader()

  // Traiter chaque structure
  const structuresEnrichies: StructureEnrichie[] = []
  const structuresACompleter: StructureACompleter[] = []
  let compteur = 0
  let reussites = 0
  let nonTrouves = 0
  let erreurs = 0

  for (const structure of structuresAPIable.slice(0, MAX_STRUCTURES)) {
    compteur += 1
    const progression = `[${compteur}/${total}]`

    console.log(`${progression} Traitement ${structure.type_identifiant} ${structure.identifiant}...`)

    let tentative = 0
    let succes = false

    while (tentative < MAX_RETRIES && !succes) {
      tentative += 1

      try {
        // Gestion du rate limit API SIRENE (30 requêtes / 65 secondes)
        // Seulement pour les nouvelles tentatives, pas les retries après erreur
        if (tentative === 1) {
          await attendreRateLimit()
        } else {
          // Pour les retries, attendre un peu avant de réessayer
          await wait(1000)
        }

        // Appel API SIRENE : trois méthodes selon le type d'identifiant
        let resultat: any

        if (structure.type_identifiant === 'CODE_INSEE') {
          // Recherche multicritère pour les communes (CODE_INSEE)
          const communeResult = await rechercherCommuneParCodeInsee(structure.identifiant, structure.membre_nom)

          if (communeResult) {
            // Transformer en format compatible avec le reste du code
            resultat = {
              identifiant: communeResult.siret,
              denomination: communeResult.denomination,
              adresse: communeResult.adresse,
              numeroVoie: communeResult.numeroVoie,
              nomVoie: communeResult.nomVoie,
              codePostal: communeResult.codePostal,
              commune: communeResult.commune,
              codeInsee: communeResult.codeInsee,
              categorieJuridiqueCode: communeResult.categorieJuridiqueCode,
              activitePrincipale: communeResult.activitePrincipale,
            }
          } else {
            resultat = { estTrouvee: false }
          }
        } else if (structure.type_identifiant === 'SIREN') {
          // Recherche multicritère pour les EPCI (SIREN 9 chiffres)
          const epciResult = await rechercherEPCIParSiren(structure.identifiant, structure.membre_nom)

          if (epciResult) {
            // Transformer en format compatible avec le reste du code
            resultat = {
              identifiant: epciResult.siret,
              denomination: epciResult.denomination,
              adresse: epciResult.adresse,
              numeroVoie: epciResult.numeroVoie,
              nomVoie: epciResult.nomVoie,
              codePostal: epciResult.codePostal,
              commune: epciResult.commune,
              codeInsee: epciResult.codeInsee,
              categorieJuridiqueCode: epciResult.categorieJuridiqueCode,
              activitePrincipale: epciResult.activitePrincipale,
            }
          } else {
            resultat = { estTrouvee: false }
          }
        } else {
          // Recherche directe pour SIRET uniquement (14 chiffres)
          resultat = await sireneLoader.rechercherParIdentifiant(structure.identifiant)
        }

        if ('estTrouvee' in resultat && !resultat.estTrouvee) {
          console.log(`  ⚠️  Non trouvé dans l'API SIRENE`)
          nonTrouves += 1

          // Ajouter au CSV enrichi pour traçabilité
          structuresEnrichies.push({
            siret: structure.identifiant,
            membre_nom_origine: structure.membre_nom,
            departement_code: structure.departement_code,
            nb_membres: structure.nb_membres_avec_cet_identifiant,
            nom: '',
            adresse_complete: '',
            numero_voie: '',
            nom_voie: '',
            code_postal: '',
            commune: '',
            code_insee: '',
            categorie_juridique: '',
            activite_principale: '',
            statut: 'NON_TROUVE',
          })

          // Ajouter au CSV à compléter manuellement (pré-rempli avec les données du membre)
          structuresACompleter.push({
            siret: structure.identifiant,
            membre_nom_origine: structure.membre_nom,
            departement_code: structure.departement_code,
            nb_membres: structure.nb_membres_avec_cet_identifiant,
            nom: structure.membre_nom, // Pré-remplir avec le nom du membre
            categorie_juridique: '',
            categorie_juridique_libelle: '',
            activite_principale: '',
            numero_voie: '',
            nom_voie: '',
            code_postal: '',
            nom_commune: '',
            code_insee: '',
            raison_non_trouve: 'Établissement non trouvé dans l\'API SIRENE (fermé, SIRET invalide ou établissement non diffusible)',
          })

          succes = true // Succès, on ne réessaye pas
        } else if ('identifiant' in resultat) {
          console.log(`  ✅ ${resultat.denomination}`)
          reussites += 1

          structuresEnrichies.push({
            siret: resultat.identifiant, // Utiliser le SIRET trouvé (important pour CODE_INSEE)
            membre_nom_origine: structure.membre_nom,
            departement_code: structure.departement_code,
            nb_membres: structure.nb_membres_avec_cet_identifiant,
            nom: resultat.denomination,
            adresse_complete: resultat.adresse,
            numero_voie: resultat.numeroVoie,
            nom_voie: resultat.nomVoie,
            code_postal: resultat.codePostal,
            commune: resultat.commune,
            code_insee: resultat.codeInsee,
            categorie_juridique: resultat.categorieJuridiqueCode,
            activite_principale: resultat.activitePrincipale,
            statut: 'OK',
          })

          succes = true // Succès, on ne réessaye pas
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Erreur inconnue'

        // Si erreur de rate limit, attendre et réessayer (ne devrait plus arriver avec le nouveau système)
        if (message.includes('429') || message.includes('Trop de requêtes')) {
          if (tentative < MAX_RETRIES) {
            const waitTime = 70000 // Attendre 70 secondes si erreur 429 imprévue
            console.log(`  ⏸️  Rate limit inattendu (erreur 429), attente de ${waitTime / 1000}s (tentative ${tentative}/${MAX_RETRIES})...`)
            console.log(`      Note: Cela ne devrait normalement pas arriver avec le système de rate limiting`)
            await wait(waitTime)
            // Continue la boucle while pour réessayer
          } else {
            // Dernière tentative échouée
            console.log(`  ❌ Rate limit persistant après ${MAX_RETRIES} tentatives`)
            erreurs += 1

            // Ajouter au CSV enrichi pour traçabilité
            structuresEnrichies.push({
              siret: structure.identifiant,
              membre_nom_origine: structure.membre_nom,
              departement_code: structure.departement_code,
              nb_membres: structure.nb_membres_avec_cet_identifiant,
              nom: '',
              adresse_complete: '',
              numero_voie: '',
              nom_voie: '',
              code_postal: '',
              commune: '',
              code_insee: '',
              categorie_juridique: '',
              activite_principale: '',
              statut: 'ERREUR',
              erreur: message,
            })

            // Ajouter au CSV à compléter manuellement
            structuresACompleter.push({
              siret: structure.identifiant,
              membre_nom_origine: structure.membre_nom,
              departement_code: structure.departement_code,
              nb_membres: structure.nb_membres_avec_cet_identifiant,
              nom: structure.membre_nom,
              categorie_juridique: '',
              categorie_juridique_libelle: '',
              activite_principale: '',
              numero_voie: '',
              nom_voie: '',
              code_postal: '',
              nom_commune: '',
              code_insee: '',
              raison_non_trouve: `Erreur lors de l'appel API: ${message}`,
            })
          }
        } else {
          // Autre type d'erreur, pas de retry
          console.log(`  ❌ Erreur : ${message}`)
          erreurs += 1

          structuresEnrichies.push({
            siret: structure.identifiant,
            membre_nom_origine: structure.membre_nom,
            departement_code: structure.departement_code,
            nb_membres: structure.nb_membres_avec_cet_identifiant,
            nom: '',
            adresse_complete: '',
            numero_voie: '',
            nom_voie: '',
            code_postal: '',
            commune: '',
            code_insee: '',
            categorie_juridique: '',
            activite_principale: '',
            statut: 'ERREUR',
            erreur: message,
          })

          structuresACompleter.push({
            siret: structure.identifiant,
            membre_nom_origine: structure.membre_nom,
            departement_code: structure.departement_code,
            nb_membres: structure.nb_membres_avec_cet_identifiant,
            nom: structure.membre_nom,
            categorie_juridique: '',
            categorie_juridique_libelle: '',
            activite_principale: '',
            numero_voie: '',
            nom_voie: '',
            code_postal: '',
            nom_commune: '',
            code_insee: '',
            raison_non_trouve: `Erreur lors de l'appel API: ${message}`,
          })

          succes = true // Sortir de la boucle, pas la peine de réessayer
        }
      }
    }
  }

  // Écrire le CSV de sortie
  console.log(`\n💾 Écriture du fichier : ${CSV_OUTPUT}`)
  const csvOutputContent = stringify(structuresEnrichies, {
    header: true,
    columns: [
      'siret',
      'membre_nom_origine',
      'departement_code',
      'nb_membres',
      'nom',
      'adresse_complete',
      'numero_voie',
      'nom_voie',
      'code_postal',
      'commune',
      'code_insee',
      'categorie_juridique',
      'activite_principale',
      'statut',
      'erreur',
    ],
  })

  fs.writeFileSync(CSV_OUTPUT, csvOutputContent)

  // Écrire le CSV des structures à compléter manuellement
  if (structuresACompleter.length > 0) {
    console.log(`\n💾 Écriture du fichier des structures à compléter : ${CSV_NON_TROUVEES}`)
    const csvACompleterContent = stringify(structuresACompleter, {
      header: true,
      columns: [
        'siret',
        'membre_nom_origine',
        'departement_code',
        'nb_membres',
        'nom',
        'categorie_juridique',
        'categorie_juridique_libelle',
        'activite_principale',
        'numero_voie',
        'nom_voie',
        'code_postal',
        'nom_commune',
        'code_insee',
        'raison_non_trouve',
      ],
    })

    fs.writeFileSync(CSV_NON_TROUVEES, csvACompleterContent)
    console.log(`✨ ${structuresACompleter.length} structures à compléter manuellement`)
  }

  // Résumé
  console.log('\n📈 RÉSUMÉ')
  console.log(`   Total traité     : ${compteur}`)
  console.log(`   ✅ Succès        : ${reussites}`)
  console.log(`   ⚠️  Non trouvés   : ${nonTrouves}`)
  console.log(`   ❌ Erreurs       : ${erreurs}`)
  console.log(`\n✨ Fichiers générés :`)
  console.log(`   - ${CSV_OUTPUT} (toutes les structures)`)
  if (structuresACompleter.length > 0) {
    console.log(`   - ${CSV_NON_TROUVEES} (${structuresACompleter.length} structures à compléter manuellement)`)
  }
  console.log('\n💡 Prochaine étape :')
  if (structuresACompleter.length > 0) {
    console.log(`   1. Complétez manuellement le fichier : ${CSV_NON_TROUVEES}`)
    console.log('   2. Lancez le script d\'injection pour les structures trouvées :')
    console.log('      yarn tsx dbs/migration-structures/3-injecter-structures.ts')
    console.log('   3. Injectez ensuite les structures complétées manuellement :')
    console.log('      yarn tsx dbs/migration-structures/4-injecter-structures-manuelles.ts')
  } else {
    console.log('   Vérifiez le CSV, puis lancez le script d\'injection :')
    console.log('   yarn tsx dbs/migration-structures/3-injecter-structures.ts')
  }
}

main().catch((error) => {
  console.error('❌ Erreur fatale :', error)
  process.exit(1)
})
