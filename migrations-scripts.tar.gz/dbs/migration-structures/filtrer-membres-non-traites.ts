#!/usr/bin/env tsx
import { parse } from 'csv-parse/sync'
import { stringify } from 'csv-stringify/sync'
import { readFileSync, writeFileSync } from 'node:fs'

/**
 * Script pour filtrer les membres non traités en excluant ceux
 * qui ont été trouvés dans collectivites-sirene.csv
 */

async function main() {
  console.log('🔍 Filtrage des membres non traités\n')

  // Lire membres-non-traites.csv
  const membresContent = readFileSync('dbs/migration-structures/membres-non-traites.csv', 'utf-8')
  const membres = parse(membresContent, {
    columns: true,
    skip_empty_lines: true,
  })

  console.log(`📊 ${membres.length} membres dans le fichier initial\n`)

  // Lire collectivites-sirene.csv
  const collectivitesContent = readFileSync('dbs/migration-structures/collectivites-sirene.csv', 'utf-8')
  const collectivites = parse(collectivitesContent, {
    columns: true,
    skip_empty_lines: true,
  })

  console.log(`📊 ${collectivites.length} collectivités dans le CSV SIRENE`)
  console.log(`   Trouvées : ${collectivites.filter((c: any) => c.siret_siege).length}`)
  console.log(`   Non trouvées : ${collectivites.filter((c: any) => !c.siret_siege).length}\n`)

  // Créer un Set des membre_id qui ont été trouvés (avec SIRET)
  const membresTraites = new Set(
    collectivites
      .filter((c: any) => c.siret_siege) // Seulement ceux avec SIRET
      .map((c: any) => c.membre_id)
  )

  console.log(`✅ ${membresTraites.size} membres traités avec succès\n`)

  // Filtrer les membres non traités
  const membresNonTraites = membres.filter((m: any) => !membresTraites.has(m.id))

  console.log(`📋 Répartition des membres non traités restants :\n`)

  // Compter par type
  const comptesParType: Record<string, number> = {}
  membresNonTraites.forEach((m: any) => {
    comptesParType[m.type] = (comptesParType[m.type] || 0) + 1
  })

  Object.entries(comptesParType)
    .sort(([, a], [, b]) => b - a)
    .forEach(([type, count]) => {
      console.log(`   ${type}: ${count}`)
    })

  console.log(`\n   Total : ${membresNonTraites.length}\n`)

  // Générer le nouveau CSV
  const csv = stringify(membresNonTraites, {
    header: true,
    columns: ['id', 'nom', 'type', 'siret_ridet', 'departement_code', 'statut'],
  })

  const outputPath = 'dbs/migration-structures/membres-restants-non-traites.csv'
  writeFileSync(outputPath, csv, 'utf-8')

  console.log(`✅ Fichier généré : ${outputPath}`)

  // Afficher quelques exemples
  console.log(`\n📋 Exemples de membres restants :\n`)
  membresNonTraites.slice(0, 10).forEach((m: any) => {
    console.log(`   ${m.type.padEnd(30)} ${m.nom.padEnd(30)} (${m.departement_code})`)
  })

  if (membresNonTraites.length > 10) {
    console.log(`   ... et ${membresNonTraites.length - 10} autres`)
  }
}

main().catch(console.error)
