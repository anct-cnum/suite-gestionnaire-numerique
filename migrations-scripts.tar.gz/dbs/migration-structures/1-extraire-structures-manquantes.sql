-- Script pour extraire les structures qui n'existent pas dans main.structure
-- Inclut :
--   1. Structures avec SIRET complet (14 chiffres) - lien exact sur le SIRET
--   2. EPCI avec SIREN (9 chiffres) - cherche une structure dont le SIRET commence par ce SIREN
--   3. Communes avec CODE_INSEE (5 chiffres) - cherche une structure avec catégorie juridique 7xxx et le même code INSEE
-- Les résultats sont exportés en CSV pour traitement ultérieur

COPY (
  WITH membres_avec_siret AS (
    -- Membres avec SIRET complet (14 chiffres)
    SELECT
      m.id as membre_id,
      m.nom as membre_nom,
      CASE
        WHEN m.siret_ridet IS NULL
          AND m.id ~ '^structure-[0-9]{14}'
        THEN SPLIT_PART(m.id, '-', 2)
        ELSE m.siret_ridet
      END as siret,
      m.gouvernance_departement_code as departement_code,
      'SIRET' as type_identifiant
    FROM min.membre m
    WHERE m.statut IN ('confirme', 'supprimer')
      AND (
        m.id ~ '^structure-[0-9]{14}'
        OR (m.siret_ridet IS NOT NULL AND LENGTH(m.siret_ridet) = 14)
      )
      AND NOT EXISTS (
        -- Ne pas avoir de structure avec ce SIRET exact
        SELECT 1
        FROM main.structure s
        WHERE s.siret = CASE
          WHEN m.siret_ridet IS NULL
            AND m.id ~ '^structure-[0-9]{14}'
          THEN SPLIT_PART(m.id, '-', 2)
          ELSE m.siret_ridet
        END
      )
  ),
  membres_epci AS (
    -- Membres EPCI avec SIREN (9 chiffres)
    SELECT
      m.id as membre_id,
      m.nom as membre_nom,
      SPLIT_PART(m.id, '-', 2) as siren,
      m.gouvernance_departement_code as departement_code,
      'SIREN' as type_identifiant
    FROM min.membre m
    WHERE m.statut IN ('confirme', 'supprimer')
      AND m.type = 'Collectivité, EPCI'
      AND m.id ~ '^epci-[0-9]{9}-'
      AND NOT EXISTS (
        -- Ne pas avoir de structure dont le SIRET commence par ce SIREN
        SELECT 1
        FROM main.structure s
        WHERE s.siret LIKE (SPLIT_PART(m.id, '-', 2) || '%')
      )
  ),
  membres_communes AS (
    -- Membres communes avec CODE_INSEE (5 chiffres)
    SELECT
      m.id as membre_id,
      m.nom as membre_nom,
      SPLIT_PART(m.id, '-', 2) as code_insee,
      m.gouvernance_departement_code as departement_code,
      'CODE_INSEE' as type_identifiant
    FROM min.membre m
    WHERE m.statut IN ('confirme', 'supprimer')
      AND m.type = 'Collectivité, commune'
      AND m.id ~ '^commune-[0-9]{5}-'
      AND NOT EXISTS (
        -- Ne pas avoir de structure avec catégorie juridique 7xxx (collectivités) et l'adresse a le bon code INSEE
        SELECT 1
        FROM main.structure s
        INNER JOIN main.adresse a ON a.id = s.adresse_id
        WHERE s.categorie_juridique LIKE '7%'
          AND a.code_insee = SPLIT_PART(m.id, '-', 2)
      )
  ),
  toutes_structures_manquantes AS (
    SELECT siret as identifiant, membre_nom, departement_code, type_identifiant
    FROM membres_avec_siret
    UNION ALL
    SELECT siren as identifiant, membre_nom, departement_code, type_identifiant
    FROM membres_epci
    UNION ALL
    SELECT code_insee as identifiant, membre_nom, departement_code, type_identifiant
    FROM membres_communes
  )
  SELECT DISTINCT ON (identifiant)
    identifiant,
    type_identifiant,
    membre_nom,
    departement_code,
    COUNT(*) OVER (PARTITION BY identifiant) as nb_membres_avec_cet_identifiant
  FROM toutes_structures_manquantes
  ORDER BY identifiant, departement_code, membre_nom
) TO '/tmp/structures-manquantes.csv' WITH (FORMAT CSV, HEADER, DELIMITER ',', ENCODING 'UTF8');

-- Message de confirmation
SELECT 'Export terminé : /tmp/structures-manquantes.csv (dans le container)' as message;

-- Statistiques détaillées
WITH membres_avec_siret AS (
  SELECT
    CASE
      WHEN m.siret_ridet IS NULL AND m.id ~ '^structure-[0-9]{14}'
      THEN SPLIT_PART(m.id, '-', 2)
      ELSE m.siret_ridet
    END as identifiant
  FROM min.membre m
  WHERE m.statut IN ('confirme', 'supprimer')
    AND (
      m.id ~ '^structure-[0-9]{14}'
      OR (m.siret_ridet IS NOT NULL AND LENGTH(m.siret_ridet) = 14)
    )
    AND NOT EXISTS (
      SELECT 1
      FROM main.structure s
      WHERE s.siret = CASE
        WHEN m.siret_ridet IS NULL AND m.id ~ '^structure-[0-9]{14}'
        THEN SPLIT_PART(m.id, '-', 2)
        ELSE m.siret_ridet
      END
    )
),
membres_epci AS (
  SELECT
    SPLIT_PART(m.id, '-', 2) as identifiant
  FROM min.membre m
  WHERE m.statut IN ('confirme', 'supprimer')
    AND m.type = 'Collectivité, EPCI'
    AND m.id ~ '^epci-[0-9]{9}-'
    AND NOT EXISTS (
      SELECT 1
      FROM main.structure s
      WHERE s.siret LIKE (SPLIT_PART(m.id, '-', 2) || '%')
    )
),
membres_communes AS (
  SELECT
    SPLIT_PART(m.id, '-', 2) as identifiant
  FROM min.membre m
  WHERE m.statut IN ('confirme', 'supprimer')
    AND m.type = 'Collectivité, commune'
    AND m.id ~ '^commune-[0-9]{5}-'
    AND NOT EXISTS (
      SELECT 1
      FROM main.structure s
      INNER JOIN main.adresse a ON a.id = s.adresse_id
      WHERE s.categorie_juridique LIKE '7%'
        AND a.code_insee = SPLIT_PART(m.id, '-', 2)
    )
)
SELECT
  'Structures avec SIRET (14 chiffres)' as type,
  COUNT(DISTINCT identifiant) as nombre
FROM membres_avec_siret
UNION ALL
SELECT
  'EPCI avec SIREN (9 chiffres)' as type,
  COUNT(DISTINCT identifiant) as nombre
FROM membres_epci
UNION ALL
SELECT
  'Communes avec CODE_INSEE (5 chiffres)' as type,
  COUNT(DISTINCT identifiant) as nombre
FROM membres_communes
UNION ALL
SELECT
  'TOTAL' as type,
  (SELECT COUNT(DISTINCT identifiant) FROM membres_avec_siret) +
  (SELECT COUNT(DISTINCT identifiant) FROM membres_epci) +
  (SELECT COUNT(DISTINCT identifiant) FROM membres_communes) as nombre;
