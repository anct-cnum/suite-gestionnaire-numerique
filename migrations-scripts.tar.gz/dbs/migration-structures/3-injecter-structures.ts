#!/usr/bin/env tsx

import fs from 'node:fs'
import { parse } from 'csv-parse/sync'
import prisma from '../../prisma/prismaClient'
import { PrismaStructureRepository } from '@/gateways/PrismaStructureRepository'

// Types
type StructureEnrichie = {
  siret: string
  membre_nom_origine: string
  departement_code: string
  nb_membres: string
  nom: string
  adresse_complete: string
  numero_voie: string
  nom_voie: string
  code_postal: string
  commune: string
  code_insee: string
  categorie_juridique: string
  activite_principale: string
  statut: 'OK' | 'NON_TROUVE' | 'ERREUR'
  erreur?: string
}

// Configuration
const CSV_INPUT = 'dbs/migration-structures/structures-enrichies.csv'
const DRY_RUN = process.argv.includes('--dry-run')
const MAX_STRUCTURES = process.argv.includes('--limit')
  ? Number.parseInt(process.argv[process.argv.indexOf('--limit') + 1] || '10', 10)
  : undefined

// Fonction principale
async function main() {
  console.log('🚀 Démarrage du script d\'injection des structures\n')

  if (DRY_RUN) {
    console.log('🔍 MODE DRY-RUN : Aucune modification ne sera effectuée\n')
  }

  // Vérifier la présence du CSV d'entrée 
  if (!fs.existsSync(CSV_INPUT)) {
    console.error(`❌ Fichier CSV non trouvé : ${CSV_INPUT}`)
    console.log('💡 Lancez d\'abord le script de récupération des données :')
    console.log('   yarn tsx dbs/migration-structures/2-recuperer-donnees-sirene.ts')
    process.exit(1)
  }

  // Lire le CSV d'entrée
  console.log(`📖 Lecture du fichier : ${CSV_INPUT}`)
  const csvContent = fs.readFileSync(CSV_INPUT, 'utf-8')
  const structures: StructureEnrichie[] = parse(csvContent, {
    columns: true,
    skip_empty_lines: true,
  })

  // Filtrer uniquement les structures avec statut OK
  const structuresValides = structures.filter(s => s.statut === 'OK')
  const total = MAX_STRUCTURES
    ? Math.min(structuresValides.length, MAX_STRUCTURES)
    : structuresValides.length

  console.log(`📊 ${structuresValides.length} structures valides sur ${structures.length} au total`)
  console.log(`📌 ${total} structures à injecter\n`)

  if (structuresValides.length === 0) {
    console.log('⚠️  Aucune structure valide à injecter')
    process.exit(0)
  }

  // Créer le repository
  const structureRepository = new PrismaStructureRepository()

  // Statistiques
  let compteur = 0
  let crees = 0
  let existants = 0
  let erreurs = 0
  const erreursDetails: Array<{ siret: string, erreur: string }> = []

  // Traiter chaque structure dans une transaction
  for (const structure of structuresValides.slice(0, MAX_STRUCTURES)) {
    compteur += 1
    const progression = `[${compteur}/${total}]`

    try {
      console.log(`${progression} Traitement du SIRET ${structure.siret} - ${structure.nom}`)

      // Vérifier si la structure existe déjà
      const existante = await structureRepository.getBySiret(structure.siret)

      if (existante) {
        console.log(`  ℹ️  Structure déjà existante (ID: ${existante.state.uid.value})`)
        existants += 1
        continue
      }

      if (DRY_RUN) {
        console.log('  🔍 [DRY-RUN] Structure serait créée')
        crees += 1
        continue
      }

      // Récupérer le libellé de la catégorie juridique (simplifié)
      const categorieJuridiqueLibelle = getCategorieJuridiqueLibelle(structure.categorie_juridique)

      // Créer la structure
      const nouvelleStructure = await structureRepository.create({
        adresse: structure.adresse_complete,
        categorieJuridique: structure.categorie_juridique,
        categorieJuridiqueLibelle,
        codeInsee: structure.code_insee,
        codePostal: structure.code_postal,
        commune: structure.commune,
        departementCode: structure.departement_code,
        identifiantEtablissement: structure.siret,
        nom: structure.nom,
        nomVoie: structure.nom_voie,
        numeroVoie: structure.numero_voie,
      })

      console.log(`  ✅ Structure créée (ID: ${nouvelleStructure.state.uid.value})`)
      crees += 1
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Erreur inconnue'
      console.log(`  ❌ Erreur : ${message}`)
      erreurs += 1
      erreursDetails.push({
        siret: structure.siret,
        erreur: message,
      })
    }
  }

  // Résumé
  console.log('\n📈 RÉSUMÉ')
  console.log(`   Total traité         : ${compteur}`)
  console.log(`   ✅ Structures créées : ${crees}`)
  console.log(`   ℹ️  Déjà existantes   : ${existants}`)
  console.log(`   ❌ Erreurs           : ${erreurs}`)

  if (erreursDetails.length > 0) {
    console.log('\n❌ DÉTAIL DES ERREURS :')
    for (const { siret, erreur } of erreursDetails) {
      console.log(`   ${siret} : ${erreur}`)
    }
  }

  if (DRY_RUN) {
    console.log('\n🔍 MODE DRY-RUN : Aucune modification n\'a été effectuée')
    console.log('💡 Pour effectuer l\'injection réelle, relancez sans --dry-run')
  } else {
    console.log('\n✨ Injection terminée avec succès !')
    console.log('\n💡 Prochaine étape :')
    console.log('   Appliquez le script de migration pour lier les membres :')
    console.log('   docker compose exec postgres-dev psql -U min -f /home/beta/Dev/min/Nettoyage\\ de\\ la\\ donnée.sql')
  }
}

// Fonction utilitaire pour obtenir le libellé de la catégorie juridique
// Source : https://www.insee.fr/fr/information/2028129
function getCategorieJuridiqueLibelle(code: string): string {
  const categories: Record<string, string> = {
    '1000': 'Entrepreneur individuel',
    '2110': 'Indivision',
    '2120': 'Société créée de fait',
    '2210': 'Société en participation',
    '2220': 'Société en participation de professions libérales',
    '2310': 'Société civile',
    '2320': 'Société civile de construction-vente',
    '2385': 'Société civile coopérative de construction',
    '2400': 'Société d\'exercice libéral',
    '2700': 'Paroisse hors zone concordataire',
    '2900': 'Autre groupement de droit privé non doté de la personnalité morale',
    '3110': 'Représentation ou agence commerciale d\'état ou organisme public étranger',
    '3120': 'Société commerciale étrangère immatriculée au RCS',
    '3205': 'Organisation internationale',
    '3210': 'État',
    '3220': 'Établissement public national à caractère industriel ou commercial',
    '3230': 'Établissement public national à caractère administratif',
    '4110': 'Établissement public local à caractère industriel ou commercial',
    '4120': 'Régie d\'une collectivité locale à caractère industriel ou commercial',
    '4130': 'Établissement public local à caractère administratif',
    '5191': 'Société de caution mutuelle',
    '5192': 'Société coopérative de banque populaire',
    '5193': 'Caisse de crédit maritime mutuel',
    '5194': 'Caisse (fédérale) de crédit mutuel',
    '5195': 'Association coopérative inscrite',
    '5196': 'Caisse d\'épargne et de prévoyance',
    '5202': 'Société en nom collectif',
    '5203': 'Société en nom collectif coopérative',
    '5306': 'Société en commandite simple',
    '5307': 'Société en commandite simple coopérative',
    '5308': 'Société en commandite par actions',
    '5309': 'Société en commandite par actions coopérative',
    '5385': 'Société d\'exercice libéral en commandite par actions',
    '5410': 'SARL nationale',
    '5415': 'SARL d\'économie mixte',
    '5422': 'SARL immobilière pour le commerce et l\'industrie (SICOMI)',
    '5426': 'SARL immobilière de gestion',
    '5430': 'SARL d\'aménagement foncier et d\'équipement rural (SAFER)',
    '5431': 'SARL mixte d\'intérêt agricole (SMIA)',
    '5432': 'SARL d\'intérêt collectif agricole (SICA)',
    '5442': 'SARL d\'attribution',
    '5443': 'SARL coopérative de construction',
    '5451': 'SARL coopérative de consommation',
    '5453': 'SARL coopérative artisanale',
    '5454': 'SARL coopérative d\'intérêt maritime',
    '5455': 'SARL coopérative de transport',
    '5458': 'SARL coopérative ouvrière de production (SCOP)',
    '5459': 'SARL union de sociétés coopératives',
    '5460': 'Autre SARL coopérative',
    '5485': 'Société d\'exercice libéral à responsabilité limitée',
    '5498': 'SARL unipersonnelle',
    '5499': 'Société à responsabilité limitée',
    '5505': 'SA à participation ouvrière',
    '5510': 'SA nationale',
    '5515': 'SA d\'économie mixte',
    '5520': 'Société d\'investissement à capital variable (SICAV)',
    '5522': 'SA immobilière pour le commerce et l\'industrie (SICOMI)',
    '5525': 'SA immobilière d\'investissement',
    '5530': 'SA d\'aménagement foncier et d\'équipement rural',
    '5531': 'Société anonyme mixte d\'intérêt agricole',
    '5532': 'SA d\'intérêt collectif agricole',
    '5542': 'SA d\'attribution',
    '5543': 'SA coopérative de construction',
    '5546': 'SA de HLM',
    '5547': 'SA coopérative de production de HLM',
    '5548': 'SA de crédit immobilier',
    '5551': 'SA coopérative de consommation',
    '5552': 'SA coopérative de commerçants-détaillants',
    '5553': 'SA coopérative artisanale',
    '5554': 'SA coopérative (d\'intérêt) maritime',
    '5555': 'SA coopérative de transport',
    '5558': 'SA coopérative ouvrière de production',
    '5559': 'SA union de sociétés coopératives',
    '5560': 'Autre SA coopérative',
    '5585': 'Société d\'exercice libéral à forme anonyme',
    '5599': 'SA',
    '5605': 'SAS, société par actions simplifiée',
    '5610': 'SAS, société par actions simplifiée à associé unique ou société par actions simplifiée unipersonnelle',
    '5620': 'Société de Participations Financières de Profession Libérale',
    '5699': 'SA à forme particulière',
    '5710': 'SAS européenne',
    '5720': 'Société européenne',
    '5785': 'Société d\'exercice libéral par action simplifiée',
    '5800': 'Société européenne coopérative',
    '6100': 'Caisse d\'Épargne et de Prévoyance',
    '6210': 'GEIE',
    '6220': 'GIE',
    '6316': 'CUMA',
    '6317': 'Société coopérative agricole',
    '6318': 'Union de sociétés coopératives agricoles',
    '6411': 'Société d\'assurance à forme mutuelle',
    '6521': 'CPAM',
    '6532': 'Caisse nationale militaire de sécurité sociale',
    '6533': 'Caisse autonome nationale de sécurité sociale dans les mines',
    '6534': 'URSSAF',
    '6535': 'Caisse primaire d\'assurance maladie (CPAM) de Paris',
    '6536': 'Caisse régionale d\'assurance maladie d\'Île-de-France (CRAMIF)',
    '6541': 'Caisse régionale d\'assurance vieillesse',
    '6542': 'Organisme autonome d\'assurance vieillesse',
    '6543': 'Caisse nationale d\'assurance vieillesse',
    '6544': 'Organisme autonome d\'assurance vieillesse des professions libérales',
    '6551': 'Caisse d\'allocations familiales',
    '6559': 'Caisse centrale de la mutualité sociale agricole',
    '7111': 'Autorité constitutionnelle',
    '7112': 'Autorité administrative ou publique indépendante',
    '7113': 'Ministère',
    '7120': 'Service central d\'un ministère',
    '7150': 'Service du ministère de la Défense',
    '7160': 'Service déconcentré à compétence nationale d\'un ministère',
    '7171': 'Service déconcentré de l\'État à compétence (inter) régionale',
    '7172': 'Service déconcentré de l\'État à compétence (inter) départementale',
    '7179': 'Ecole nationale non dotée de la personnalité morale',
    '7190': 'Autre personne morale de droit administratif',
    '7210': 'Commune et commune nouvelle',
    '7220': 'Département',
    '7225': 'Collectivité et territoire d\'Outre-Mer',
    '7229': 'Collectivité territoriale à statut particulier',
    '7230': 'Région',
    '7312': 'Commune associée et commune déléguée',
    '7313': 'Section de commune',
    '7314': 'Ensemble urbain',
    '7321': 'Association syndicale autorisée',
    '7322': 'Association foncière urbaine',
    '7323': 'Association foncière de remembrement',
    '7331': 'Établissement public local d\'enseignement',
    '7340': 'Pôle métropolitain',
    '7341': 'Secteur de commune',
    '7342': 'District urbain',
    '7343': 'Communauté urbaine',
    '7344': 'Métropole',
    '7345': 'Syndicat intercommunal à vocation multiple (SIVOM)',
    '7346': 'Communauté de communes',
    '7347': 'Communauté de villes',
    '7348': 'Communauté d\'agglomération',
    '7349': 'Autre établissement public local de coopération non spécialisé ou entente',
    '7351': 'Institution interdépartementale ou entente',
    '7352': 'Institution interrégionale ou entente',
    '7353': 'Syndicat intercommunal à vocation unique (SIVU)',
    '7354': 'Syndicat mixte fermé',
    '7355': 'Syndimat mixte ouvert',
    '7356': 'Commission syndicale pour la gestion des biens indivis des communes',
    '7357': 'Pôle d\'équilibre territorial et rural',
    '7361': 'Centre communal d\'action sociale',
    '7362': 'Caisse des écoles',
    '7363': 'Caisse de crédit municipal',
    '7364': 'Établissement d\'hospitalisation',
    '7365': 'Syndicat inter hospitalier',
    '7366': 'Établissement public local social et médico-social',
    '7371': 'Office public d\'habitation à loyer modéré',
    '7372': 'Service départemental d\'incendie et de secours',
    '7373': 'Établissement public local culturel',
    '7378': 'Régie d\'une collectivité locale à caractère administratif',
    '7379': 'Autre établissement public administratif local',
    '7381': 'Organisme consulaire',
    '7382': 'Établissement public national ayant fonction d\'administration centrale',
    '7383': 'Établissement public national à caractère scientifique culturel et professionnel',
    '7384': 'Autre établissement public national d\'enseignement',
    '7385': 'Autre établissement public national administratif à compétence territoriale limitée',
    '7389': 'Établissement public national à caractère administratif',
    '7410': 'Groupement d\'intérêt public',
    '7430': 'Établissement public des cultes d\'Alsace-Lorraine',
    '7450': 'Établissement public administratif, cercle et foyer dans les armées',
    '7470': 'Groupement de coopération sanitaire à gestion publique',
    '7490': 'Autre personne morale de droit administratif',
    '8110': 'Régime général de la Sécurité Sociale',
    '8120': 'Régime spécial de Sécurité Sociale',
    '8130': 'Institution de retraite complémentaire',
    '8140': 'Mutualité sociale agricole',
    '8150': 'Régime maladie des non-salariés non agricoles',
    '8160': 'Régime vieillesse ne dépendant pas du régime général de la Sécurité Sociale',
    '8170': 'Régime d\'assurance chômage',
    '8190': 'Autre régime de prévoyance sociale',
    '8210': 'Mutuelle',
    '8250': 'Assurance mutuelle agricole',
    '8290': 'Autre organisme mutualiste',
    '8310': 'Comité central d\'entreprise',
    '8311': 'Comité d\'établissement',
    '8410': 'Syndicat de salariés',
    '8420': 'Syndicat patronal',
    '8450': 'Ordre professionnel ou assimilé',
    '8470': 'Centre technique industriel ou comité professionnel du développement économique',
    '8490': 'Autre organisme professionnel',
    '8510': 'Institution de prévoyance',
    '8520': 'Institution de retraite supplémentaire',
    '9110': 'Syndicat de copropriété',
    '9150': 'Association syndicale libre',
    '9210': 'Association non déclarée',
    '9220': 'Association déclarée',
    '9221': 'Association déclarée d\'insertion par l\'économique',
    '9222': 'Association intermédiaire',
    '9223': 'Groupement d\'employeurs',
    '9224': 'Association d\'avocats à responsabilité professionnelle individuelle',
    '9230': 'Association déclarée, reconnue d\'utilité publique',
    '9240': 'Congrégation',
    '9260': 'Association de droit local (Bas-Rhin, Haut-Rhin et Moselle)',
    '9300': 'Fondation',
    '9900': 'Autre personne morale de droit privé',
    '9970': 'Groupement de coopération sanitaire à gestion privée',
  }

  return categories[code] || 'Autre forme juridique'
}

main()
  .catch((error) => {
    console.error('❌ Erreur fatale :', error)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
