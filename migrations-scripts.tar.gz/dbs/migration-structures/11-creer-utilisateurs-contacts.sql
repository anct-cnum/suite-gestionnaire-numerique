-- Script pour créer des comptes utilisateurs à partir des emails de contact des membres
-- À exécuter APRÈS avoir lié tous les membres aux structures
--
-- Logique :
--   1. Pour chaque membre lié à une structure, récupérer les emails contact et contact_technique
--   2. Créer un utilisateur pour chaque email unique si il n'existe pas déjà
--   3. Lier l'utilisateur à la structure du membre
--   4. Rôle : gestionnaire_structure

-- ============================================================================
-- STATISTIQUES AVANT
-- ============================================================================

SELECT '======================================' as separateur;
SELECT 'AVANT CRÉATION DES UTILISATEURS' as etape;
SELECT '======================================' as separateur;

-- Compter les emails uniques qui vont devenir des utilisateurs
WITH emails_contacts AS (
  SELECT DISTINCT
    m.contact as email,
    m.structure_id
  FROM min.membre m
  WHERE m.statut IN ('confirme', 'supprimer')
    AND m.structure_id IS NOT NULL
    AND m.contact IS NOT NULL
    AND m.contact != ''

  UNION

  SELECT DISTINCT
    m.contact_technique as email,
    m.structure_id
  FROM min.membre m
  WHERE m.statut IN ('confirme', 'supprimer')
    AND m.structure_id IS NOT NULL
    AND m.contact_technique IS NOT NULL
    AND m.contact_technique != ''
)
SELECT
  'Emails uniques à traiter' as info,
  COUNT(DISTINCT email) as nb_emails_distincts,
  COUNT(*) as nb_liaisons_structure_email
FROM emails_contacts;

-- Compter les utilisateurs existants avec ces emails
WITH emails_contacts AS (
  SELECT DISTINCT
    m.contact as email
  FROM min.membre m
  WHERE m.statut IN ('confirme', 'supprimer')
    AND m.structure_id IS NOT NULL
    AND m.contact IS NOT NULL
    AND m.contact != ''

  UNION

  SELECT DISTINCT
    m.contact_technique as email
  FROM min.membre m
  WHERE m.statut IN ('confirme', 'supprimer')
    AND m.structure_id IS NOT NULL
    AND m.contact_technique IS NOT NULL
    AND m.contact_technique != ''
)
SELECT
  'Utilisateurs déjà existants' as info,
  COUNT(*) as nb_utilisateurs
FROM min.utilisateur u
WHERE u.email_de_contact IN (SELECT email FROM emails_contacts);

-- ============================================================================
-- CRÉATION DES UTILISATEURS DEPUIS LES CONTACTS
-- ============================================================================

-- Insérer les utilisateurs pour les emails "contact" qui n'existent pas encore
INSERT INTO min.utilisateur (
  email_de_contact,
  sso_id,
  sso_email,
  date_de_creation,
  invite_le,
  role,
  structure_id,
  nom,
  prenom,
  telephone
)
SELECT DISTINCT
  m.contact as email_de_contact,
  m.contact as sso_id,
  m.contact as sso_email,
  NOW() as date_de_creation,
  NOW() as invite_le,
  'gestionnaire_structure'::min."Role" as role,
  m.structure_id,
  'À compléter' as nom,
  'À compléter' as prenom,
  '' as telephone
FROM min.membre m
WHERE m.statut IN ('confirme', 'supprimer')
  AND m.structure_id IS NOT NULL
  AND m.contact IS NOT NULL
  AND m.contact != ''
  -- Ne créer que si l'utilisateur n'existe pas déjà
  AND NOT EXISTS (
    SELECT 1
    FROM min.utilisateur u
    WHERE u.email_de_contact = m.contact
  )
ON CONFLICT (sso_id) DO NOTHING;

SELECT '✓ Création des utilisateurs depuis les contacts terminée' as message;

-- ============================================================================
-- CRÉATION DES UTILISATEURS DEPUIS LES CONTACTS TECHNIQUES
-- ============================================================================

-- Insérer les utilisateurs pour les emails "contact_technique" qui n'existent pas encore
INSERT INTO min.utilisateur (
  email_de_contact,
  sso_id,
  sso_email,
  date_de_creation,
  invite_le,
  role,
  structure_id,
  nom,
  prenom,
  telephone
)
SELECT DISTINCT
  m.contact_technique as email_de_contact,
  m.contact_technique as sso_id,
  m.contact_technique as sso_email,
  NOW() as date_de_creation,
  NOW() as invite_le,
  'gestionnaire_structure'::min."Role" as role,
  m.structure_id,
  'À compléter' as nom,
  'À compléter' as prenom,
  '' as telephone
FROM min.membre m
WHERE m.statut IN ('confirme', 'supprimer')
  AND m.structure_id IS NOT NULL
  AND m.contact_technique IS NOT NULL
  AND m.contact_technique != ''
  -- Ne créer que si l'utilisateur n'existe pas déjà
  AND NOT EXISTS (
    SELECT 1
    FROM min.utilisateur u
    WHERE u.email_de_contact = m.contact_technique
  )
ON CONFLICT (sso_id) DO NOTHING;

SELECT '✓ Création des utilisateurs depuis les contacts techniques terminée' as message;

-- ============================================================================
-- STATISTIQUES APRÈS
-- ============================================================================

SELECT '======================================' as separateur;
SELECT 'APRÈS CRÉATION DES UTILISATEURS' as etape;
SELECT '======================================' as separateur;

-- Compter les nouveaux utilisateurs créés
WITH emails_contacts AS (
  SELECT DISTINCT
    m.contact as email
  FROM min.membre m
  WHERE m.statut IN ('confirme', 'supprimer')
    AND m.structure_id IS NOT NULL
    AND m.contact IS NOT NULL
    AND m.contact != ''

  UNION

  SELECT DISTINCT
    m.contact_technique as email
  FROM min.membre m
  WHERE m.statut IN ('confirme', 'supprimer')
    AND m.structure_id IS NOT NULL
    AND m.contact_technique IS NOT NULL
    AND m.contact_technique != ''
)
SELECT
  'Utilisateurs créés avec rôle gestionnaire_structure' as info,
  COUNT(*) as nb_utilisateurs
FROM min.utilisateur u
WHERE u.email_de_contact IN (SELECT email FROM emails_contacts)
  AND u.role = 'gestionnaire_structure';

-- Compter par structure
SELECT
  'Utilisateurs par structure' as info,
  u.structure_id,
  s.nom as nom_structure,
  COUNT(*) as nb_utilisateurs
FROM min.utilisateur u
INNER JOIN main.structure s ON s.id = u.structure_id
WHERE u.role = 'gestionnaire_structure'
  AND u.date_de_creation >= NOW() - INTERVAL '1 minute'
GROUP BY u.structure_id, s.nom
ORDER BY nb_utilisateurs DESC
LIMIT 20;

-- ============================================================================
-- VÉRIFICATION : Emails sans utilisateur créé
-- ============================================================================

WITH emails_contacts AS (
  SELECT DISTINCT
    m.contact as email,
    m.structure_id
  FROM min.membre m
  WHERE m.statut IN ('confirme', 'supprimer')
    AND m.structure_id IS NOT NULL
    AND m.contact IS NOT NULL
    AND m.contact != ''

  UNION

  SELECT DISTINCT
    m.contact_technique as email,
    m.structure_id
  FROM min.membre m
  WHERE m.statut IN ('confirme', 'supprimer')
    AND m.structure_id IS NOT NULL
    AND m.contact_technique IS NOT NULL
    AND m.contact_technique != ''
)
SELECT
  'Emails sans utilisateur créé (erreurs)' as info,
  COUNT(*) as nb_emails
FROM emails_contacts ec
WHERE NOT EXISTS (
  SELECT 1
  FROM min.utilisateur u
  WHERE u.email_de_contact = ec.email
);