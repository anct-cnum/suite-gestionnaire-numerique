#!/usr/bin/env tsx

import fs from 'node:fs'
import { parse } from 'csv-parse/sync'
import prisma from '../../prisma/prismaClient'
import { PrismaStructureRepository } from '@/gateways/PrismaStructureRepository'

// Types
type Collectivite = {
  type: string
  code: string
  nom_membre: string
  membre_id: string
  siret_siege: string
  denomination_sirene: string
  adresse: string
  code_postal: string
  commune: string
  code_commune: string
  categorie_juridique: string
  etat: 'ACTIF' | 'Aucun siège social trouvé'
  erreur?: string
}

// Configuration
const CSV_INPUT = 'dbs/migration-structures/collectivites-sirene.csv'
const DRY_RUN = process.argv.includes('--dry-run')
const MAX_STRUCTURES = process.argv.includes('--limit')
  ? Number.parseInt(process.argv[process.argv.indexOf('--limit') + 1] || '10', 10)
  : undefined

// Fonction principale
async function main() {
  console.log('🚀 Démarrage du script d\'injection des collectivités\n')

  if (DRY_RUN) {
    console.log('🔍 MODE DRY-RUN : Aucune modification ne sera effectuée\n')
  }

  // Vérifier la présence du CSV d'entrée
  if (!fs.existsSync(CSV_INPUT)) {
    console.error(`❌ Fichier CSV non trouvé : ${CSV_INPUT}`)
    console.log('💡 Lancez d\'abord le script de génération des collectivités :')
    console.log('   yarn tsx dbs/migration-structures/generer-collectivites-sirene.ts')
    process.exit(1)
  }

  // Lire le CSV d'entrée
  console.log(`📖 Lecture du fichier : ${CSV_INPUT}`)
  const csvContent = fs.readFileSync(CSV_INPUT, 'utf-8')
  const collectivites: Collectivite[] = parse(csvContent, {
    columns: true,
    skip_empty_lines: true,
  })

  // Filtrer uniquement les collectivités avec état ACTIF
  const collectivitesValides = collectivites.filter(c => c.etat === 'ACTIF')
  const total = MAX_STRUCTURES
    ? Math.min(collectivitesValides.length, MAX_STRUCTURES)
    : collectivitesValides.length

  console.log(`📊 ${collectivitesValides.length} collectivités valides sur ${collectivites.length} au total`)
  console.log(`📌 ${total} collectivités à injecter\n`)

  if (collectivitesValides.length === 0) {
    console.log('⚠️  Aucune collectivité valide à injecter')
    process.exit(0)
  }

  // Créer le repository
  const structureRepository = new PrismaStructureRepository()

  // Statistiques
  let compteur = 0
  let crees = 0
  let existants = 0
  let erreurs = 0
  const erreursDetails: Array<{ siret: string, erreur: string }> = []

  // Traiter chaque collectivité
  for (const collectivite of collectivitesValides.slice(0, MAX_STRUCTURES)) {
    compteur += 1
    const progression = `[${compteur}/${total}]`

    try {
      console.log(`${progression} Traitement du SIRET ${collectivite.siret_siege} - ${collectivite.denomination_sirene}`)

      // Vérifier si la structure existe déjà
      const existante = await structureRepository.getBySiret(collectivite.siret_siege)

      if (existante) {
        console.log(`  ℹ️  Structure déjà existante (ID: ${existante.state.uid.value})`)
        existants += 1
        continue
      }

      if (DRY_RUN) {
        console.log('  🔍 [DRY-RUN] Structure serait créée')
        crees += 1
        continue
      }

      // Récupérer le libellé de la catégorie juridique (simplifié)
      const categorieJuridiqueLibelle = getCategorieJuridiqueLibelle(collectivite.categorie_juridique)

      // Parser l'adresse pour extraire numéro et nom de voie
      const { numeroVoie, nomVoie } = parseAdresse(collectivite.adresse)

      // Créer la structure
      const nouvelleStructure = await structureRepository.create({
        adresse: collectivite.adresse,
        categorieJuridique: collectivite.categorie_juridique,
        categorieJuridiqueLibelle,
        codeInsee: collectivite.code_commune,
        codePostal: collectivite.code_postal,
        commune: collectivite.commune,
        departementCode: collectivite.code,
        identifiantEtablissement: collectivite.siret_siege,
        nom: collectivite.denomination_sirene,
        nomVoie,
        numeroVoie,
      })

      console.log(`  ✅ Structure créée (ID: ${nouvelleStructure.state.uid.value})`)
      crees += 1
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Erreur inconnue'
      console.log(`  ❌ Erreur : ${message}`)
      erreurs += 1
      erreursDetails.push({
        siret: collectivite.siret_siege,
        erreur: message,
      })
    }
  }

  // Résumé
  console.log('\n📈 RÉSUMÉ')
  console.log(`   Total traité            : ${compteur}`)
  console.log(`   ✅ Collectivités créées : ${crees}`)
  console.log(`   ℹ️  Déjà existantes      : ${existants}`)
  console.log(`   ❌ Erreurs              : ${erreurs}`)

  if (erreursDetails.length > 0) {
    console.log('\n❌ DÉTAIL DES ERREURS :')
    for (const { siret, erreur } of erreursDetails) {
      console.log(`   ${siret} : ${erreur}`)
    }
  }

  if (DRY_RUN) {
    console.log('\n🔍 MODE DRY-RUN : Aucune modification n\'a été effectuée')
    console.log('💡 Pour effectuer l\'injection réelle, relancez sans --dry-run')
  } else {
    console.log('\n✨ Injection terminée avec succès !')
    console.log('\n💡 Prochaine étape :')
    console.log('   Appliquez le script de liaison pour lier les membres :')
    console.log('   docker compose exec -T postgres-dev psql -U min < dbs/migration-structures/6-lier-membres-structures-injectees.sql')
  }
}

// Fonction utilitaire pour parser une adresse et extraire numéro et nom de voie
function parseAdresse(adresse: string): { numeroVoie: string, nomVoie: string } {
  if (!adresse || adresse.trim() === '') {
    return { numeroVoie: '', nomVoie: '' }
  }

  // Regex pour matcher un numéro au début (optionnel)
  const match = adresse.match(/^(\d+)\s+(.+)$/)

  if (match) {
    return {
      numeroVoie: match[1],
      nomVoie: match[2],
    }
  }

  // Pas de numéro détecté, toute l'adresse est le nom de voie
  return {
    numeroVoie: '',
    nomVoie: adresse,
  }
}

// Fonction utilitaire pour obtenir le libellé de la catégorie juridique
// Source : https://www.insee.fr/fr/information/2028129
function getCategorieJuridiqueLibelle(code: string): string {
  const categories: Record<string, string> = {
    '7111': 'Autorité constitutionnelle',
    '7112': 'Autorité administrative ou publique indépendante',
    '7113': 'Ministère',
    '7120': 'Service central d\'un ministère',
    '7150': 'Service du ministère de la Défense',
    '7160': 'Service déconcentré à compétence nationale d\'un ministère',
    '7171': 'Service déconcentré de l\'État à compétence (inter) régionale',
    '7172': 'Service déconcentré de l\'État à compétence (inter) départementale',
    '7210': 'Commune et commune nouvelle',
    '7220': 'Département',
    '7225': 'Collectivité et territoire d\'Outre-Mer',
    '7229': 'Collectivité territoriale à statut particulier',
    '7230': 'Région',
  }

  return categories[code] || 'Autre forme juridique'
}

main()
  .catch((error) => {
    console.error('❌ Erreur fatale :', error)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
