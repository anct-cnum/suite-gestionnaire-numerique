#!/bin/bash

# =============================================================================
# Script de g�n�ration des fichiers CSV pour la migration des structures
# =============================================================================
#
# Ce script g�n�re les fichiers CSV n�cessaires pour cr�er les structures
# manquantes dans main.structure et les lier aux membres de min.membre
#
# Pr�requis :
# - Base de donn�es PostgreSQL accessible
# - API Sirene accessible (https://entreprise.data.gouv.fr)
# - Node.js et yarn install�s
#
# =============================================================================

set -e  # Arr�ter en cas d'erreur

# Couleurs pour l'affichage
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}==============================================================================${NC}"
echo -e "${BLUE}  G�N�RATION DES FICHIERS CSV POUR LA MIGRATION DES STRUCTURES${NC}"
echo -e "${BLUE}==============================================================================${NC}"
echo ""

# 0. Configuration
export DATABASE_URL="${DATABASE_URL:-postgresql://min:min@127.0.0.1:5432/min}"
export OUTPUT_DIR="dbs/migration-structures"

echo -e "${YELLOW}Configuration :${NC}"
echo "  - Base de donn�es : $DATABASE_URL"
echo "  - R�pertoire de sortie : $OUTPUT_DIR"
echo ""

# =============================================================================
# �TAPE 1 : Extraire les structures manquantes
# =============================================================================
echo -e "${GREEN}[1/3] Extraction des structures manquantes depuis la base de donn�es...${NC}"
echo "  Ce script identifie les membres qui n'ont pas de structure employeuse"
echo "  correspondante dans main.structure"
echo ""

psql "$DATABASE_URL" -f "$OUTPUT_DIR/1-extraire-structures-manquantes.sql"

if [ ! -f "$OUTPUT_DIR/structures-manquantes.csv" ]; then
  echo -e "${YELLOW}�  ATTENTION : Le fichier structures-manquantes.csv n'a pas �t� g�n�r�${NC}"
  echo "  V�rifiez que le script SQL exporte bien dans le bon r�pertoire"
  exit 1
fi

NOMBRE_STRUCTURES=$(wc -l < "$OUTPUT_DIR/structures-manquantes.csv")
echo -e "${GREEN} Fichier g�n�r� : structures-manquantes.csv ($NOMBRE_STRUCTURES lignes)${NC}"
echo ""

# =============================================================================
# �TAPE 2 : R�cup�rer les donn�es Sirene pour les structures manquantes
# =============================================================================
echo -e "${GREEN}[2/3] R�cup�ration des donn�es depuis l'API Sirene...${NC}"
echo "  Ce script interroge l'API Sirene pour enrichir les structures"
echo "  (SIRET, EPCI, Communes) avec leurs informations officielles"
echo ""

DATABASE_URL="$DATABASE_URL" yarn tsx "$OUTPUT_DIR/2-recuperer-donnees-sirene.ts"

if [ ! -f "$OUTPUT_DIR/structures-enrichies.csv" ]; then
  echo -e "${YELLOW}�  ATTENTION : Le fichier structures-enrichies.csv n'a pas �t� g�n�r�${NC}"
  exit 1
fi

NOMBRE_OK=$(grep -c ",OK," "$OUTPUT_DIR/structures-enrichies.csv" || echo "0")
NOMBRE_TOTAL=$(tail -n +2 "$OUTPUT_DIR/structures-enrichies.csv" | wc -l)
echo -e "${GREEN} Fichier g�n�r� : structures-enrichies.csv${NC}"
echo "  - Total : $NOMBRE_TOTAL structures"
echo "  - Trouv�es : $NOMBRE_OK structures"
echo "  - Non trouv�es : $((NOMBRE_TOTAL - NOMBRE_OK)) structures"
echo ""

# =============================================================================
# �TAPE 3 : G�n�rer les collectivit�s (D�partements, Pr�fectures, SGAR)
# =============================================================================
echo -e "${GREEN}[3/3] G�n�ration des collectivit�s territoriales...${NC}"
echo "  Ce script g�n�re les donn�es Sirene pour les d�partements,"
echo "  pr�fectures et SGAR (Services de l'�tat en R�gions)"
echo ""

DATABASE_URL="$DATABASE_URL" yarn tsx "$OUTPUT_DIR/generer-collectivites-sirene.ts"

if [ ! -f "$OUTPUT_DIR/collectivites-sirene.csv" ]; then
  echo -e "${YELLOW}�  ATTENTION : Le fichier collectivites-sirene.csv n'a pas �t� g�n�r�${NC}"
  exit 1
fi

NOMBRE_COLLECTIVITES=$(tail -n +2 "$OUTPUT_DIR/collectivites-sirene.csv" | wc -l)
NOMBRE_ACTIF=$(grep -c ",ACTIF," "$OUTPUT_DIR/collectivites-sirene.csv" || echo "0")
echo -e "${GREEN} Fichier g�n�r� : collectivites-sirene.csv${NC}"
echo "  - Total : $NOMBRE_COLLECTIVITES collectivit�s"
echo "  - Actives : $NOMBRE_ACTIF collectivit�s"
echo "  - Non trouv�es : $((NOMBRE_COLLECTIVITES - NOMBRE_ACTIF)) collectivit�s"
echo ""

# =============================================================================
# R�SUM� FINAL
# =============================================================================
echo -e "${BLUE}==============================================================================${NC}"
echo -e "${GREEN}( G�n�ration termin�e avec succ�s !${NC}"
echo -e "${BLUE}==============================================================================${NC}"
echo ""
echo "Fichiers g�n�r�s dans $OUTPUT_DIR :"
echo "  1. structures-manquantes.csv       - Structures � cr�er (SIRET/EPCI/Communes)"
echo "  2. structures-enrichies.csv        - Structures enrichies par l'API Sirene"
echo "  3. collectivites-sirene.csv        - Collectivit�s territoriales"
echo ""
echo -e "${YELLOW}Prochaine �tape :${NC}"
echo "  Ex�cutez le script de migration pour injecter ces structures :"
echo "  ${GREEN}bash $OUTPUT_DIR/migration.sh${NC}"
echo ""
