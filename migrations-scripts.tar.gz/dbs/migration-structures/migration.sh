#!/bin/bash

# =============================================================================
# Script de migration des structures vers main.structure
# =============================================================================
#
# Ce script applique la migration en injectant les structures et en liant
# les membres. Les fichiers CSV doivent avoir été générés au préalable avec
# le script generation.sh
#
# Prérequis :
# - Fichiers CSV générés (structures-enrichies.csv, collectivites-sirene.csv)
# - Base de données PostgreSQL accessible
#
# =============================================================================

set -e  # Arrêter en cas d'erreur

# Configuration
export DATABASE_URL="${DATABASE_URL:-postgresql://min:min@127.0.0.1:5432/min}"

echo "🚀 Application de la migration des structures"
echo ""

# 1. Vérifier les prérequis
echo "1️⃣ Vérification des prérequis..."

# Vérifier connexion base de données
if ! psql "$DATABASE_URL" -c "SELECT 1" > /dev/null 2>&1; then
  echo "❌ Erreur : Impossible de se connecter à la base de données"
  exit 1
fi

# Vérifier que structures-enrichies.csv existe
if [ ! -f "dbs/migration-structures/structures-enrichies.csv" ]; then
  echo "❌ Erreur : Le fichier structures-enrichies.csv est manquant"
  echo "💡 Exécutez d'abord : bash dbs/migration-structures/generation.sh"
  exit 1
fi

echo "✓ Base de données accessible"
echo "✓ Fichier structures-enrichies.csv trouvé"
echo ""

# 2. Injecter les structures enrichies
echo "2️⃣ Injection des structures enrichies (SIRET, EPCI, communes)..."
DATABASE_URL="$DATABASE_URL" yarn tsx dbs/migration-structures/3-injecter-structures.ts
echo ""

# 3. Injecter les collectivités (si fichier présent)
if [ -f "dbs/migration-structures/collectivites-sirene.csv" ]; then
  echo "3️⃣ Injection des collectivités (préfectures, départements, SGAR)..."
  DATABASE_URL="$DATABASE_URL" yarn tsx dbs/migration-structures/4-injecter-collectivites.ts
  echo ""
else
  echo "3️⃣ Pas de fichier collectivites-sirene.csv, injection ignorée"
  echo ""
fi

# 4. Lier TOUS les membres aux structures (script unique)
echo "4️⃣ Liaison de TOUS les membres aux structures..."
cat dbs/migration-structures/10-lier-tous-les-membres.sql | docker compose exec -T postgres-dev psql -U min -d min
echo ""

# 5. Lier les collectivités via CSV (si fichier présent)
if [ -f "dbs/migration-structures/collectivites-sirene.csv" ]; then
  echo "5️⃣ Liaison des collectivités via CSV (mapping membre_id → siret)..."
  docker compose cp dbs/migration-structures/collectivites-sirene.csv postgres-dev:/tmp/collectivites-sirene.csv
  cat dbs/migration-structures/9-lier-membres-via-csv-collectivites.sql | docker compose exec -T postgres-dev psql -U min -d min
  echo ""
else
  echo "5️⃣ Pas de fichier collectivites-sirene.csv, liaison ignorée"
  echo ""
fi

# 6. Vérification finale
echo "6️⃣ Vérification finale..."

echo "📊 Statistiques globales :"
psql "$DATABASE_URL" -c "
SELECT
  COUNT(*) as total_membres,
  COUNT(structure_id) as membres_lies,
  COUNT(*) - COUNT(structure_id) as membres_non_lies,
  ROUND(100.0 * COUNT(structure_id) / COUNT(*), 2) as pourcentage_lies
FROM min.membre m
WHERE m.statut IN ('confirme', 'supprimer');
"

echo ""
echo "👥 Membres co-porteurs non liés :"
psql "$DATABASE_URL" -c "
SELECT
  COUNT(*) as nb_coporteurs_non_lies
FROM min.membre m
WHERE m.statut IN ('confirme', 'supprimer')
  AND m.is_coporteur = true
  AND m.structure_id IS NULL;
"

echo ""
echo "✨ Migration terminée avec succès !"
