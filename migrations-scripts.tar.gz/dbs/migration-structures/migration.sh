#!/bin/bash

# =============================================================================
# Script de migration des structures vers main.structure
# =============================================================================
#
# Ce script applique la migration en injectant les structures et en liant
# les membres. Les fichiers CSV doivent avoir été générés au préalable avec
# le script generation.sh
#
# Prérequis :
# - Fichiers CSV générés (structures-enrichies.csv, collectivites-sirene.csv)
# - Base de données PostgreSQL accessible
#
# =============================================================================

set -e  # Arrêter en cas d'erreur

# Configuration
export DATABASE_URL="${DATABASE_URL:-postgresql://min:min@127.0.0.1:5432/min}"
# export DATABASE_URL='postgresql://min_scalingo:'57_7NDRC[ud*X2qLXJd_d4h7e39YpEEozo]iXy[s9_oRJfmN+J'@127.0.0.1:54333/dataspace_test'
echo "🚀 Application de la migration des structures"
echo ""

# 1. Vérifier les prérequis
echo "1️⃣ Vérification des prérequis..."

# Vérifier connexion base de données
if ! psql "$DATABASE_URL" -c "SELECT 1" > /dev/null 2>&1; then
  echo "❌ Erreur : Impossible de se connecter à la base de données"
  exit 1
fi

# Vérifier que structures-enrichies.csv existe
if [ ! -f "dbs/migration-structures/structures-enrichies.csv" ]; then
  echo "❌ Erreur : Le fichier structures-enrichies.csv est manquant"
  echo "💡 Exécutez d'abord : bash dbs/migration-structures/generation.sh"
  exit 1
fi

echo "✓ Base de données accessible"
echo "✓ Fichier structures-enrichies.csv trouvé"
echo ""

# Vérifier l'existence des tables et les permissions d'insertion
echo "🔍 Vérification des tables et permissions..."

# Test d'insertion dans main.structure et main.adresse avec ROLLBACK
psql "$DATABASE_URL" <<'SQL'
DO $$
BEGIN
  -- Vérifier que le schéma main existe
  IF NOT EXISTS (SELECT 1 FROM pg_namespace WHERE nspname = 'main') THEN
    RAISE EXCEPTION 'Le schéma main n''existe pas';
  END IF;

  -- Vérifier que la table main.structure existe
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'main' AND table_name = 'structure'
  ) THEN
    RAISE EXCEPTION 'La table main.structure n''existe pas';
  END IF;

  -- Vérifier que la table main.adresse existe
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'main' AND table_name = 'adresse'
  ) THEN
    RAISE EXCEPTION 'La table main.adresse n''existe pas';
  END IF;

  RAISE NOTICE 'Toutes les tables requises existent';
END $$;

-- Test d'insertion avec ROLLBACK pour vérifier les permissions
BEGIN;

-- Test insertion dans main.adresse
INSERT INTO main.adresse (
  code_postal,
  commune,
  code_insee,
  adresse,
  complement_adresse
) VALUES (
  '75001',
  'Paris',
  '75101',
  '1 Rue de Test',
  'Test'
) RETURNING id;

-- Test insertion dans main.structure
INSERT INTO main.structure (
  nom,
  siret,
  type_structure_id
) VALUES (
  'Test Structure Migration',
  '12345678901234',
  1
) RETURNING id;

-- Annuler les insertions de test
ROLLBACK;
SQL

if [ $? -ne 0 ]; then
  echo "❌ Erreur : Impossible d'insérer dans main.structure ou main.adresse"
  echo "💡 Vérifiez que les tables existent et que vous avez les permissions nécessaires"
  exit 1
fi

echo "✓ Tables main.structure et main.adresse accessibles et insertions possibles"
echo ""

# 2. Injecter les structures enrichies
echo "2️⃣ Injection des structures enrichies (SIRET, EPCI, communes)..."
DATABASE_URL="$DATABASE_URL" yarn tsx dbs/migration-structures/3-injecter-structures.ts
echo ""

# 3. Injecter les collectivités (si fichier présent)
if [ -f "dbs/migration-structures/collectivites-sirene.csv" ]; then
  echo "3️⃣ Injection des collectivités (préfectures, départements, SGAR)..."
  DATABASE_URL="$DATABASE_URL" yarn tsx dbs/migration-structures/4-injecter-collectivites.ts
  echo ""
else
  echo "3️⃣ Pas de fichier collectivites-sirene.csv, injection ignorée"
  echo ""
fi

# 4. Lier TOUS les membres aux structures (script unique)
echo "4️⃣ Liaison de TOUS les membres aux structures..."
psql "$DATABASE_URL" -f dbs/migration-structures/10-lier-tous-les-membres.sql
echo ""

# 5. Lier les collectivités via CSV (si fichier présent)
if [ -f "dbs/migration-structures/collectivites-sirene.csv" ]; then
  echo "5️⃣ Liaison des collectivités via CSV (mapping membre_id → siret)..."
  psql "$DATABASE_URL" -f dbs/migration-structures/9-lier-membres-via-csv-collectivites.sql
  echo ""
else
  echo "5️⃣ Pas de fichier collectivites-sirene.csv, liaison ignorée"
  echo ""
fi

# 6. Créer les comptes utilisateurs pour les contacts
echo "6️⃣ Création des comptes utilisateurs pour les contacts..."
psql "$DATABASE_URL" -f dbs/migration-structures/11-creer-utilisateurs-contacts.sql
echo ""

# 7. Exporter la liste des utilisateurs créés en CSV
echo "7️⃣ Export CSV des utilisateurs créés..."
psql "$DATABASE_URL" -f dbs/migration-structures/12-export-utilisateurs-csv.sql

# Copier le fichier CSV dans le répertoire de migration
if [ -f "/tmp/utilisateurs-gestionnaires-structure.csv" ]; then
  cp /tmp/utilisateurs-gestionnaires-structure.csv dbs/migration-structures/
  echo "✓ Fichier CSV copié dans : dbs/migration-structures/utilisateurs-gestionnaires-structure.csv"
else
  echo "⚠️  Fichier CSV non trouvé dans /tmp/"
fi
echo ""

# 8. Vérification finale
echo "8️⃣ Vérification finale..."

echo "📊 Statistiques globales :"
psql "$DATABASE_URL" -c "
SELECT
  COUNT(*) as total_membres,
  COUNT(structure_id) as membres_lies,
  COUNT(*) - COUNT(structure_id) as membres_non_lies,
  ROUND(100.0 * COUNT(structure_id) / COUNT(*), 2) as pourcentage_lies
FROM min.membre m
WHERE m.statut IN ('confirme', 'supprimer');
"

echo ""
echo "👥 Membres co-porteurs non liés :"
  psql "$DATABASE_URL" -c "
  SELECT
    COUNT(*) as nb_coporteurs_non_lies
  FROM min.membre m
  WHERE m.statut IN ('confirme', 'supprimer')
    AND m.is_coporteur = true
    AND m.structure_id IS NULL;
  "

echo ""
echo "✨ Migration terminée avec succès !"
