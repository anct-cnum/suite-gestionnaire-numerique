-- Script unique pour lier TOUS les membres aux structures dans main.structure
-- À exécuter APRÈS avoir injecté toutes les structures (script 3)
--
-- Logique de liaison :
--   1. Priorité aux structures dans le même département que le membre
--   2. Sinon, priorité aux structures employeuses (présentes dans main.personne_affectations avec type='structure_emploi')
--   3. Sinon, prend la première structure disponible (ORDER BY s.id)
--
-- Gère trois types de membres :
--   1. Membres avec SIRET complet (14 chiffres) - lien exact sur le SIRET
--   2. Membres EPCI avec SIREN (9 chiffres) - lien via SIRET LIKE 'SIREN%'
--   3. Membres communes avec CODE_INSEE (5 chiffres) - lien via catégorie juridique 7xxx et code INSEE

-- ============================================================================
-- STATISTIQUES AVANT
-- ============================================================================

SELECT '======================================' as separateur;
SELECT 'AVANT LIAISON' as etape;
SELECT '======================================' as separateur;

-- Membres avec SIRET complet
SELECT
  'Membres avec SIRET (14 chiffres)' as type,
  COUNT(*) as total_membres,
  COUNT(structure_id) as membres_deja_lies,
  COUNT(*) - COUNT(structure_id) as membres_non_lies
FROM min.membre m
WHERE m.statut IN ('confirme', 'supprimer')
  AND (
    m.id ~ '^structure-[0-9]{14}'
    OR (m.siret_ridet IS NOT NULL AND LENGTH(m.siret_ridet) = 14)
  );

-- Membres EPCI avec SIREN
SELECT
  'Membres EPCI avec SIREN (9 chiffres)' as type,
  COUNT(*) as total_membres,
  COUNT(structure_id) as membres_deja_lies,
  COUNT(*) - COUNT(structure_id) as membres_non_lies
FROM min.membre m
WHERE m.statut IN ('confirme', 'supprimer')
  AND m.type = 'Collectivité, EPCI'
  AND m.id ~ '^epci-[0-9]{9}-';

-- Membres communes avec CODE_INSEE
SELECT
  'Membres communes avec CODE_INSEE (5 chiffres)' as type,
  COUNT(*) as total_membres,
  COUNT(structure_id) as membres_deja_lies,
  COUNT(*) - COUNT(structure_id) as membres_non_lies
FROM min.membre m
WHERE m.statut IN ('confirme', 'supprimer')
  AND m.type = 'Collectivité, commune'
  AND m.id ~ '^commune-[0-9]{5}-';

-- ============================================================================
-- LIAISON 1 : Membres avec SIRET complet (14 chiffres)
-- ============================================================================

UPDATE min.membre m
SET structure_id = COALESCE(
  -- 1. D'abord chercher une structure dans le même département
  (SELECT s.id
   FROM main.structure s
   INNER JOIN main.adresse a ON a.id = s.adresse_id
   WHERE s.siret = CASE
     WHEN m.siret_ridet IS NULL AND m.id ~ '^structure-[0-9]{14}'
     THEN SPLIT_PART(m.id, '-', 2)
     ELSE m.siret_ridet
   END
   AND a.departement = m.gouvernance_departement_code
   ORDER BY s.id
   LIMIT 1),
  -- 2. Sinon chercher une structure employeuse
  (SELECT s.id
   FROM main.structure s
   WHERE s.siret = CASE
     WHEN m.siret_ridet IS NULL AND m.id ~ '^structure-[0-9]{14}'
     THEN SPLIT_PART(m.id, '-', 2)
     ELSE m.siret_ridet
   END
   AND EXISTS (
     SELECT 1
     FROM main.personne_affectations pa
     WHERE pa.structure_id = s.id
       AND pa.type = 'structure_emploi'
   )
   ORDER BY s.id
   LIMIT 1),
  -- 3. Sinon prendre n'importe quelle structure avec ce SIRET
  (SELECT s.id
   FROM main.structure s
   WHERE s.siret = CASE
     WHEN m.siret_ridet IS NULL AND m.id ~ '^structure-[0-9]{14}'
     THEN SPLIT_PART(m.id, '-', 2)
     ELSE m.siret_ridet
   END
   ORDER BY s.id
   LIMIT 1)
)
WHERE m.statut IN ('confirme', 'supprimer')
  AND m.structure_id IS NULL  -- Uniquement les membres pas encore liés
  AND (
    m.id ~ '^structure-[0-9]{14}'
    OR (m.siret_ridet IS NOT NULL AND LENGTH(m.siret_ridet) = 14)
  );

SELECT '✓ Liaison membres avec SIRET complet terminée' as message;

-- ============================================================================
-- LIAISON 2 : Membres EPCI avec SIREN (9 chiffres)
-- ============================================================================

-- Pour les EPCI, logique de priorité :
-- 1. Structure dans le même département
-- 2. Structure employeuse
-- 3. N'importe quelle structure dont le SIRET commence par le SIREN
UPDATE min.membre m
SET structure_id = COALESCE(
  -- 1. D'abord chercher une structure dans le même département
  (SELECT s.id
   FROM main.structure s
   INNER JOIN main.adresse a ON a.id = s.adresse_id
   WHERE s.siret LIKE (SPLIT_PART(m.id, '-', 2) || '%')
     AND a.departement = m.gouvernance_departement_code
   ORDER BY s.id
   LIMIT 1),
  -- 2. Sinon chercher une structure employeuse
  (SELECT s.id
   FROM main.structure s
   WHERE s.siret LIKE (SPLIT_PART(m.id, '-', 2) || '%')
     AND EXISTS (
       SELECT 1
       FROM main.personne_affectations pa
       WHERE pa.structure_id = s.id
         AND pa.type = 'structure_emploi'
     )
   ORDER BY s.id
   LIMIT 1),
  -- 3. Sinon prendre n'importe quelle structure avec ce SIREN
  (SELECT s.id
   FROM main.structure s
   WHERE s.siret LIKE (SPLIT_PART(m.id, '-', 2) || '%')
   ORDER BY s.id
   LIMIT 1)
)
WHERE m.statut IN ('confirme', 'supprimer')
  AND m.structure_id IS NULL  -- Uniquement les membres pas encore liés
  AND m.type = 'Collectivité, EPCI'
  AND m.id ~ '^epci-[0-9]{9}-';

SELECT '✓ Liaison membres EPCI terminée' as message;

-- ============================================================================
-- LIAISON 3 : Membres communes avec CODE_INSEE (5 chiffres)
-- ============================================================================

-- Pour les communes, logique de priorité :
-- 1. Structure dans le même département (avec catégorie juridique 7xxx et code INSEE correspondant)
-- 2. Structure employeuse (avec catégorie juridique 7xxx et code INSEE correspondant)
-- 3. N'importe quelle structure avec ces critères
UPDATE min.membre m
SET structure_id = COALESCE(
  -- 1. D'abord chercher une structure dans le même département
  (SELECT s.id
   FROM main.structure s
   INNER JOIN main.adresse a ON a.id = s.adresse_id
   WHERE s.categorie_juridique LIKE '7%'
     AND a.code_insee = SPLIT_PART(m.id, '-', 2)
     AND a.departement = m.gouvernance_departement_code
   ORDER BY s.id
   LIMIT 1),
  -- 2. Sinon chercher une structure employeuse
  (SELECT s.id
   FROM main.structure s
   INNER JOIN main.adresse a ON a.id = s.adresse_id
   WHERE s.categorie_juridique LIKE '7%'
     AND a.code_insee = SPLIT_PART(m.id, '-', 2)
     AND EXISTS (
       SELECT 1
       FROM main.personne_affectations pa
       WHERE pa.structure_id = s.id
         AND pa.type = 'structure_emploi'
     )
   ORDER BY s.id
   LIMIT 1),
  -- 3. Sinon prendre n'importe quelle structure avec ce code INSEE et catégorie 7xxx
  (SELECT s.id
   FROM main.structure s
   INNER JOIN main.adresse a ON a.id = s.adresse_id
   WHERE s.categorie_juridique LIKE '7%'
     AND a.code_insee = SPLIT_PART(m.id, '-', 2)
   ORDER BY s.id
   LIMIT 1)
)
WHERE m.statut IN ('confirme', 'supprimer')
  AND m.structure_id IS NULL  -- Uniquement les membres pas encore liés
  AND m.type = 'Collectivité, commune'
  AND m.id ~ '^commune-[0-9]{5}-';

SELECT '✓ Liaison membres communes terminée' as message;

-- ============================================================================
-- STATISTIQUES APRÈS
-- ============================================================================

SELECT '======================================' as separateur;
SELECT 'APRÈS LIAISON' as etape;
SELECT '======================================' as separateur;

-- Membres avec SIRET complet
SELECT
  'Membres avec SIRET (14 chiffres)' as type,
  COUNT(*) as total_membres,
  COUNT(structure_id) as membres_lies,
  COUNT(*) - COUNT(structure_id) as membres_non_lies
FROM min.membre m
WHERE m.statut IN ('confirme', 'supprimer')
  AND (
    m.id ~ '^structure-[0-9]{14}'
    OR (m.siret_ridet IS NOT NULL AND LENGTH(m.siret_ridet) = 14)
  );

-- Membres EPCI avec SIREN
SELECT
  'Membres EPCI avec SIREN (9 chiffres)' as type,
  COUNT(*) as total_membres,
  COUNT(structure_id) as membres_lies,
  COUNT(*) - COUNT(structure_id) as membres_non_lies
FROM min.membre m
WHERE m.statut IN ('confirme', 'supprimer')
  AND m.type = 'Collectivité, EPCI'
  AND m.id ~ '^epci-[0-9]{9}-';

-- Membres communes avec CODE_INSEE
SELECT
  'Membres communes avec CODE_INSEE (5 chiffres)' as type,
  COUNT(*) as total_membres,
  COUNT(structure_id) as membres_lies,
  COUNT(*) - COUNT(structure_id) as membres_non_lies
FROM min.membre m
WHERE m.statut IN ('confirme', 'supprimer')
  AND m.type = 'Collectivité, commune'
  AND m.id ~ '^commune-[0-9]{5}-';

-- ============================================================================
-- DÉTAILS
-- ============================================================================

-- Structures liées par département
SELECT
  'Structures liées par département (SIRET)' as info,
  m.gouvernance_departement_code as dept,
  COUNT(*) as nb_membres_lies
FROM min.membre m
WHERE m.statut IN ('confirme', 'supprimer')
  AND m.structure_id IS NOT NULL
  AND (
    m.id ~ '^structure-[0-9]{14}'
    OR (m.siret_ridet IS NOT NULL AND LENGTH(m.siret_ridet) = 14)
  )
GROUP BY m.gouvernance_departement_code
ORDER BY m.gouvernance_departement_code;

SELECT
  'Structures liées par département (EPCI)' as info,
  m.gouvernance_departement_code as dept,
  COUNT(*) as nb_membres_lies
FROM min.membre m
WHERE m.statut IN ('confirme', 'supprimer')
  AND m.structure_id IS NOT NULL
  AND m.type = 'Collectivité, EPCI'
  AND m.id ~ '^epci-[0-9]{9}-'
GROUP BY m.gouvernance_departement_code
ORDER BY m.gouvernance_departement_code;

SELECT
  'Structures liées par département (Communes)' as info,
  m.gouvernance_departement_code as dept,
  COUNT(*) as nb_membres_lies
FROM min.membre m
WHERE m.statut IN ('confirme', 'supprimer')
  AND m.structure_id IS NOT NULL
  AND m.type = 'Collectivité, commune'
  AND m.id ~ '^commune-[0-9]{5}-'
GROUP BY m.gouvernance_departement_code
ORDER BY m.gouvernance_departement_code;

-- ============================================================================
-- VÉRIFICATION : Identifiants sans structure
-- ============================================================================

WITH membres_siret_non_lies AS (
  SELECT
    CASE
      WHEN m.siret_ridet IS NULL AND m.id ~ '^structure-[0-9]{14}'
      THEN SPLIT_PART(m.id, '-', 2)
      ELSE m.siret_ridet
    END as identifiant,
    COUNT(*) as nb_membres
  FROM min.membre m
  WHERE m.statut IN ('confirme', 'supprimer')
    AND m.structure_id IS NULL
    AND (
      m.id ~ '^structure-[0-9]{14}'
      OR (m.siret_ridet IS NOT NULL AND LENGTH(m.siret_ridet) = 14)
    )
  GROUP BY identifiant
),
membres_epci_non_lies AS (
  SELECT
    SPLIT_PART(m.id, '-', 2) as identifiant,
    COUNT(*) as nb_membres
  FROM min.membre m
  WHERE m.statut IN ('confirme', 'supprimer')
    AND m.structure_id IS NULL
    AND m.type = 'Collectivité, EPCI'
    AND m.id ~ '^epci-[0-9]{9}-'
  GROUP BY identifiant
),
membres_communes_non_lies AS (
  SELECT
    SPLIT_PART(m.id, '-', 2) as identifiant,
    COUNT(*) as nb_membres
  FROM min.membre m
  WHERE m.statut IN ('confirme', 'supprimer')
    AND m.structure_id IS NULL
    AND m.type = 'Collectivité, commune'
    AND m.id ~ '^commune-[0-9]{5}-'
  GROUP BY identifiant
)
SELECT
  'SIRET sans structure (restants)' as info,
  COUNT(*) as nb_siret_distincts,
  SUM(nb_membres) as nb_membres_total
FROM membres_siret_non_lies
UNION ALL
SELECT
  'SIREN (EPCI) sans structure (restants)' as info,
  COUNT(*) as nb_siren_distincts,
  SUM(nb_membres) as nb_membres_total
FROM membres_epci_non_lies
UNION ALL
SELECT
  'CODE_INSEE (Communes) sans structure (restants)' as info,
  COUNT(*) as nb_code_insee_distincts,
  SUM(nb_membres) as nb_membres_total
FROM membres_communes_non_lies;
