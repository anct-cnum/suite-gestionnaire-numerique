#!/usr/bin/env tsx
import { config } from 'dotenv'
import { parse } from 'csv-parse/sync'
import { stringify } from 'csv-stringify/sync'
import { readFileSync, writeFileSync } from 'node:fs'

config({ path: '.env.local' })

type SireneRecherche = {
  header: {
    statut: number
    message: string
    total: number
  }
  etablissements: Array<{
    siret: string
    etablissementSiege: boolean
    uniteLegale: {
      denominationUniteLegale: string | null
      nomUniteLegale: string | null
      categorieJuridiqueUniteLegale: string
      activitePrincipaleUniteLegale: string
      etatAdministratifUniteLegale: string
    }
    adresseEtablissement: {
      numeroVoieEtablissement: string | null
      typeVoieEtablissement: string | null
      libelleVoieEtablissement: string | null
      codePostalEtablissement: string | null
      libelleCommuneEtablissement: string | null
      codeCommuneEtablissement: string | null
    }
    periodesEtablissement: Array<{
      etatAdministratifEtablissement: string
      enseigne1Etablissement: string | null
    }>
  }>
}

type CollectiviteResult = {
  type: string
  code: string
  nom_membre: string
  membre_id: string
  siret_siege: string
  denomination_sirene: string
  adresse: string
  code_postal: string
  commune: string
  code_commune: string
  categorie_juridique: string
  etat: string
  erreur?: string
}

let requestCount = 0
let batchStartTime = Date.now()

async function attendreRateLimit(): Promise<void> {
  requestCount++

  if (requestCount % 30 === 0) {
    const elapsed = Date.now() - batchStartTime
    const waitTime = 65000 - elapsed

    if (waitTime > 0) {
      console.log(`\n⏳ Rate limit : attente de ${Math.ceil(waitTime / 1000)}s avant le prochain batch...\n`)
      await new Promise(resolve => setTimeout(resolve, waitTime))
    }

    batchStartTime = Date.now()
  }
}

async function rechercherSiegeSocial(
  denomination: string,
  code: string,
  categorieJuridique: string
): Promise<SireneRecherche['etablissements'][0] | null> {
  try {
    await attendreRateLimit()

    if (!process.env.INSEE_API_KEY) {
      throw new Error('Variable d\'environnement INSEE_API_KEY non définie')
    }

    const mots = denomination.split(' ')
    let query = mots.map(mot => `denominationUniteLegale:*${mot}*`).join(' AND ')
    query += ` AND codeCommuneEtablissement:${code}*`
    query += ` AND categorieJuridiqueUniteLegale:${categorieJuridique}`

    const url = `https://api.insee.fr/api-sirene/3.11/siret?q=${encodeURIComponent(query)}&nombre=100`

    const response = await fetch(url, {
      headers: {
        'Accept': 'application/json',
        'X-INSEE-Api-Key-Integration': process.env.INSEE_API_KEY,
      },
      signal: AbortSignal.timeout(10000),
    })

    if (!response.ok) {
      console.error(`❌ Erreur ${response.status} pour code ${code}`)
      return null
    }

    const data: SireneRecherche = await response.json()

    // Filtrer pour ne garder que les sièges sociaux actifs
    const siegesActifs = data.etablissements.filter(etab =>
      etab.etablissementSiege &&
      etab.periodesEtablissement[0]?.etatAdministratifEtablissement === 'A' &&
      etab.uniteLegale.etatAdministratifUniteLegale === 'A'
    )

    if (siegesActifs.length > 0) {
      return siegesActifs[0]
    }

    // Si pas de siège actif, prendre juste un siège
    const sieges = data.etablissements.filter(etab => etab.etablissementSiege)
    return sieges.length > 0 ? sieges[0] : null

  } catch (error) {
    console.error(`❌ Erreur recherche pour code ${code}:`, error instanceof Error ? error.message : error)
    return null
  }
}

function formatAdresse(etab: SireneRecherche['etablissements'][0]): string {
  return [
    etab.adresseEtablissement.numeroVoieEtablissement,
    etab.adresseEtablissement.typeVoieEtablissement,
    etab.adresseEtablissement.libelleVoieEtablissement,
  ].filter(Boolean).join(' ')
}

async function main() {
  console.log('🚀 Génération du CSV des collectivités depuis l\'API SIRENE\n')

  // Lire le CSV des membres non traités
  const csvContent = readFileSync('dbs/migration-structures/membres-non-traites.csv', 'utf-8')
  const membres = parse(csvContent, {
    columns: true,
    skip_empty_lines: true,
  })

  console.log(`📊 ${membres.length} membres à traiter\n`)

  const results: CollectiviteResult[] = []

  // Extraire les départements uniques pour les conseils départementaux
  const conseilsDepartementaux = membres.filter((m: any) => m.type === 'Conseil départemental')
  console.log(`🏛️  ${conseilsDepartementaux.length} Conseils départementaux\n`)

  for (const membre of conseilsDepartementaux) {
    const code = membre.departement_code
    console.log(`🔍 Conseil départemental : ${membre.nom} (${code})`)

    const siege = await rechercherSiegeSocial('DEPARTEMENT', code, '7220')

    if (siege) {
      const etatEtab = siege.periodesEtablissement[0]?.etatAdministratifEtablissement
      const etatUL = siege.uniteLegale.etatAdministratifUniteLegale
      const etat = etatEtab === 'A' && etatUL === 'A' ? 'ACTIF' : 'FERME'

      results.push({
        type: 'Conseil départemental',
        code,
        nom_membre: membre.nom,
        membre_id: membre.id,
        siret_siege: siege.siret,
        denomination_sirene: siege.uniteLegale.denominationUniteLegale || '',
        adresse: formatAdresse(siege),
        code_postal: siege.adresseEtablissement.codePostalEtablissement || '',
        commune: siege.adresseEtablissement.libelleCommuneEtablissement || '',
        code_commune: siege.adresseEtablissement.codeCommuneEtablissement || '',
        categorie_juridique: '7220',
        etat,
      })
      console.log(`   ✅ Trouvé : ${siege.siret} - ${siege.uniteLegale.denominationUniteLegale}`)
    } else {
      results.push({
        type: 'Conseil départemental',
        code,
        nom_membre: membre.nom,
        membre_id: membre.id,
        siret_siege: '',
        denomination_sirene: '',
        adresse: '',
        code_postal: '',
        commune: '',
        code_commune: '',
        categorie_juridique: '7220',
        etat: 'NON_TROUVE',
        erreur: 'Aucun siège social trouvé',
      })
      console.log(`   ❌ Non trouvé`)
    }
  }

  // Préfectures départementales
  const prefecturesDepartementales = membres.filter((m: any) => m.type === 'Préfecture départementale')
  console.log(`\n🏛️  ${prefecturesDepartementales.length} Préfectures départementales\n`)

  for (const membre of prefecturesDepartementales) {
    const code = membre.departement_code
    console.log(`🔍 Préfecture départementale : ${membre.nom} (${code})`)

    const siege = await rechercherSiegeSocial('PREFECTURE', code, '7172')

    if (siege) {
      const etatEtab = siege.periodesEtablissement[0]?.etatAdministratifEtablissement
      const etatUL = siege.uniteLegale.etatAdministratifUniteLegale
      const etat = etatEtab === 'A' && etatUL === 'A' ? 'ACTIF' : 'FERME'

      results.push({
        type: 'Préfecture départementale',
        code,
        nom_membre: membre.nom,
        membre_id: membre.id,
        siret_siege: siege.siret,
        denomination_sirene: siege.uniteLegale.denominationUniteLegale || '',
        adresse: formatAdresse(siege),
        code_postal: siege.adresseEtablissement.codePostalEtablissement || '',
        commune: siege.adresseEtablissement.libelleCommuneEtablissement || '',
        code_commune: siege.adresseEtablissement.codeCommuneEtablissement || '',
        categorie_juridique: '7172',
        etat,
      })
      console.log(`   ✅ Trouvé : ${siege.siret} - ${siege.uniteLegale.denominationUniteLegale}`)
    } else {
      results.push({
        type: 'Préfecture départementale',
        code,
        nom_membre: membre.nom,
        membre_id: membre.id,
        siret_siege: '',
        denomination_sirene: '',
        adresse: '',
        code_postal: '',
        commune: '',
        code_commune: '',
        categorie_juridique: '7172',
        etat: 'NON_TROUVE',
        erreur: 'Aucun siège social trouvé',
      })
      console.log(`   ❌ Non trouvé`)
    }
  }

  // Conseils régionaux
  const conseilsRegionaux = membres.filter((m: any) => m.type === 'Conseil régional')
  console.log(`\n🏛️  ${conseilsRegionaux.length} Conseils régionaux\n`)

  for (const membre of conseilsRegionaux) {
    const code = membre.departement_code
    console.log(`🔍 Conseil régional : ${membre.nom} (code région ${code})`)

    const siege = await rechercherSiegeSocial('REGION', code, '7230')

    if (siege) {
      const etatEtab = siege.periodesEtablissement[0]?.etatAdministratifEtablissement
      const etatUL = siege.uniteLegale.etatAdministratifUniteLegale
      const etat = etatEtab === 'A' && etatUL === 'A' ? 'ACTIF' : 'FERME'

      results.push({
        type: 'Conseil régional',
        code,
        nom_membre: membre.nom,
        membre_id: membre.id,
        siret_siege: siege.siret,
        denomination_sirene: siege.uniteLegale.denominationUniteLegale || '',
        adresse: formatAdresse(siege),
        code_postal: siege.adresseEtablissement.codePostalEtablissement || '',
        commune: siege.adresseEtablissement.libelleCommuneEtablissement || '',
        code_commune: siege.adresseEtablissement.codeCommuneEtablissement || '',
        categorie_juridique: '7230',
        etat,
      })
      console.log(`   ✅ Trouvé : ${siege.siret} - ${siege.uniteLegale.denominationUniteLegale}`)
    } else {
      results.push({
        type: 'Conseil régional',
        code,
        nom_membre: membre.nom,
        membre_id: membre.id,
        siret_siege: '',
        denomination_sirene: '',
        adresse: '',
        code_postal: '',
        commune: '',
        code_commune: '',
        categorie_juridique: '7230',
        etat: 'NON_TROUVE',
        erreur: 'Aucun siège social trouvé',
      })
      console.log(`   ❌ Non trouvé`)
    }
  }

  // Préfectures régionales
  const prefecturesRegionales = membres.filter((m: any) => m.type === 'Préfecture régionale')
  console.log(`\n🏛️  ${prefecturesRegionales.length} Préfectures régionales\n`)

  for (const membre of prefecturesRegionales) {
    const code = membre.departement_code
    console.log(`🔍 Préfecture régionale : ${membre.nom} (code département ${code})`)

    const siege = await rechercherSiegeSocial('PREFECTURE', code, '7171')

    if (siege) {
      const etatEtab = siege.periodesEtablissement[0]?.etatAdministratifEtablissement
      const etatUL = siege.uniteLegale.etatAdministratifUniteLegale
      const etat = etatEtab === 'A' && etatUL === 'A' ? 'ACTIF' : 'FERME'

      results.push({
        type: 'Préfecture régionale',
        code,
        nom_membre: membre.nom,
        membre_id: membre.id,
        siret_siege: siege.siret,
        denomination_sirene: siege.uniteLegale.denominationUniteLegale || '',
        adresse: formatAdresse(siege),
        code_postal: siege.adresseEtablissement.codePostalEtablissement || '',
        commune: siege.adresseEtablissement.libelleCommuneEtablissement || '',
        code_commune: siege.adresseEtablissement.codeCommuneEtablissement || '',
        categorie_juridique: '7171',
        etat,
      })
      console.log(`   ✅ Trouvé : ${siege.siret} - ${siege.uniteLegale.denominationUniteLegale}`)
    } else {
      results.push({
        type: 'Préfecture régionale',
        code,
        nom_membre: membre.nom,
        membre_id: membre.id,
        siret_siege: '',
        denomination_sirene: '',
        adresse: '',
        code_postal: '',
        commune: '',
        code_commune: '',
        categorie_juridique: '7171',
        etat: 'NON_TROUVE',
        erreur: 'Aucun siège social trouvé',
      })
      console.log(`   ❌ Non trouvé`)
    }
  }

  // Générer le CSV
  const csv = stringify(results, {
    header: true,
    columns: [
      'type',
      'code',
      'nom_membre',
      'membre_id',
      'siret_siege',
      'denomination_sirene',
      'adresse',
      'code_postal',
      'commune',
      'code_commune',
      'categorie_juridique',
      'etat',
      'erreur',
    ],
  })

  const outputPath = 'dbs/migration-structures/collectivites-sirene.csv'
  writeFileSync(outputPath, csv, 'utf-8')

  console.log(`\n✅ Fichier généré : ${outputPath}`)
  console.log(`\n📊 Résumé :`)
  console.log(`   Total : ${results.length}`)
  console.log(`   Trouvés : ${results.filter(r => r.siret_siege).length}`)
  console.log(`   Non trouvés : ${results.filter(r => !r.siret_siege).length}`)
  console.log(`   Actifs : ${results.filter(r => r.etat === 'ACTIF').length}`)
  console.log(`   Fermés : ${results.filter(r => r.etat === 'FERME').length}`)
}

main().catch(console.error)
