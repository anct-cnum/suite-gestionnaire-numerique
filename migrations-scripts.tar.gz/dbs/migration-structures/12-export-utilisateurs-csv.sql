-- Script pour exporter en CSV la liste des utilisateurs créés (gestionnaire_structure)
-- avec les informations des membres associés

-- Créer une table temporaire avec les données à exporter
CREATE TEMP TABLE temp_export_utilisateurs AS
WITH utilisateurs_membres AS (
  SELECT DISTINCT
    u.id as utilisateur_id,
    u.email_de_contact,
    u.structure_id,
    s.nom as nom_structure,
    s.siret as structure_siret,
    m.gouvernance_departement_code as departement,
    m.is_coporteur,
    m.type as type_membre,
    m.nom as nom_membre,
    CASE
      WHEN m.contact = u.email_de_contact THEN 'contact'
      WHEN m.contact_technique = u.email_de_contact THEN 'contact_technique'
      ELSE 'autre'
    END as type_contact
  FROM min.utilisateur u
  INNER JOIN main.structure s ON s.id = u.structure_id
  INNER JOIN min.membre m ON (
    (m.contact = u.email_de_contact OR m.contact_technique = u.email_de_contact)
    AND m.structure_id = u.structure_id
    AND m.statut IN ('confirme', 'supprimer')
  )
  WHERE u.role = 'gestionnaire_structure'
)
SELECT
  utilisateur_id,
  email_de_contact,
  structure_id,
  nom_structure,
  structure_siret,
  departement,
  is_coporteur,
  type_membre,
  nom_membre,
  type_contact
FROM utilisateurs_membres
ORDER BY structure_id, email_de_contact, departement;

-- Exporter en CSV
\copy temp_export_utilisateurs TO '/tmp/utilisateurs-gestionnaires-structure.csv' WITH CSV HEADER DELIMITER ',';

-- Message de confirmation
SELECT '✓ Export CSV créé : /tmp/utilisateurs-gestionnaires-structure.csv' as message;

-- Statistiques du fichier généré
SELECT
  'Statistiques de l''export' as info,
  COUNT(DISTINCT u.id) as nb_utilisateurs_uniques,
  COUNT(DISTINCT u.structure_id) as nb_structures_distinctes,
  COUNT(DISTINCT m.gouvernance_departement_code) as nb_departements_distincts
FROM min.utilisateur u
INNER JOIN main.structure s ON s.id = u.structure_id
INNER JOIN min.membre m ON (
  (m.contact = u.email_de_contact OR m.contact_technique = u.email_de_contact)
  AND m.structure_id = u.structure_id
  AND m.statut IN ('confirme', 'supprimer')
)
WHERE u.role = 'gestionnaire_structure';

-- Répartition par département
SELECT
  'Répartition par département' as info,
  m.gouvernance_departement_code as departement,
  COUNT(DISTINCT u.id) as nb_utilisateurs
FROM min.utilisateur u
INNER JOIN min.membre m ON (
  (m.contact = u.email_de_contact OR m.contact_technique = u.email_de_contact)
  AND m.structure_id = u.structure_id
  AND m.statut IN ('confirme', 'supprimer')
)
WHERE u.role = 'gestionnaire_structure'
GROUP BY m.gouvernance_departement_code
ORDER BY m.gouvernance_departement_code;

-- Utilisateurs associés à des membres co-porteurs
SELECT
  'Utilisateurs liés à des membres co-porteurs' as info,
  COUNT(DISTINCT u.id) as nb_utilisateurs_coporteurs
FROM min.utilisateur u
INNER JOIN min.membre m ON (
  (m.contact = u.email_de_contact OR m.contact_technique = u.email_de_contact)
  AND m.structure_id = u.structure_id
  AND m.statut IN ('confirme', 'supprimer')
)
WHERE u.role = 'gestionnaire_structure'
  AND m.is_coporteur = true;
